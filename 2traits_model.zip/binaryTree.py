
"""
            class BinaryTree: genealogy of an individual
            
                    subPopulations : save the sub-population characteristics at each event (in the live of the individual or at the population level)
                            [(time of the most recent event, sub-population, trait, density),
                              ... ,
                             (time of the oldest event, sub-population, trait, density)])
                            new event at each change of the population step of the PES (new density...)
                                    trait changes at the new event the individual branch coalesce with its ancestral branch
                            oldest event = emergence
                            most recent event = sampling time or time of division into its two descendants
                            
                    left/right: save the descendants of the individuals
                            when individual Ia and Ib coalesce => ind Ic is created, with children Ia and Ib
"""


class BinaryTree():
    
    def __init__(self, t, subPop, subPopDensity):
        self.left = None
        self.right = None
        self.tEmergence = t
        self.tSampling = t
        self.subPopulations =  [EnvironmentStep(t, subPop, subPop.xi,subPop.location, subPopDensity)]
        self.NeutralMarkers=None

    def addEnv(self, SubPopEnvironment):
        self.subPopulations.append(SubPopEnvironment)
        


class EnvironmentStep():
    
    def __init__(self,t,subPop,xi,locI, ni):
        self.tfEnv = t
        self.tOEnv = None
        self.subPopEnv = subPop
        self.xEnv = xi
        self.locEnv = locI
        self.densityEnv = ni


def printTree(tree, tabs=0):
    """
        Prints the roots of the individual and its descendants.
    
        Above the individual is its left lineage and below its right lineage.
        The more an individual is indented, the latter he appeared.
    
        ----------------------------------------------------------------------
        e.g. print IndA_________________Ind1
                          |__IndB_______Ind2
                                   |____Ind3
             will give:
         
             ('    ', root Ind 1)
             ('', root IndA)
             ('        ', root Ind 2)
             ('    ', root Ind B)
             ('        ', root Ind 3)
         
        ----------------------------------------------------------------------         
    """
    if tree != None:
        espaces = "  "*tabs
        printTree(tree.left, tabs + 1)
        print(espaces, tree.subPopulations)      
        printTree(tree.right, tabs + 1)



def mergeTrees(lt, rt, t, subpop,tsim,nbCherries):
    """
        Creates the parent of lt and rt. Coalescence time = value.
    
        (does not modify lt and rt to change their emergence time)
    """
    lt.tEmergence = t
    rt.tEmergence = t
    lt.subPopulations[-1].tOEnv = t
    rt.subPopulations[-1].tOEnv = t
    subPopDensity = lt.subPopulations[-1].densityEnv
    tree = BinaryTree(t, subpop, subPopDensity)
    tree.left = lt
    tree.right = rt
    if ((lt.tSampling == tsim)&(rt.tSampling == tsim)):
        nbCherries += 1
    
    return tree,nbCherries



def sizeTree(tree):
    """
        Counts the individual + all its descendants.
    """
    if tree == None:
        return 1
    else:
        return sizeTree(tree.left) + sizeTree(tree.right)

        

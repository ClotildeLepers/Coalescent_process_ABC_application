"""
            Plot of the PES and of the coalescence tree.
"""


import numpy as np
#LS
import matplotlib
matplotlib.use('Agg')
#LS
import matplotlib.pyplot as plt
import time


def defineColors(listPop):
    """
        Attribute a color to each location value
    """
    if len(listPop) < 9:
        cmap = plt.get_cmap('Set1')
    else:
        cmap = plt.get_cmap('gist_rainbow')
    colors = [cmap(i) for i in np.linspace(0, 1, len(listPop))]
    
    return colors


def plotPES(PES,tsim,colors,listPop):
    
    plt.figure('PES')
    
    subPopulations=[]
    for pop in PES:
        subPopulations.extend(pop.popComposition)
    
    subPopulations=set(subPopulations)

    for subPopulation in subPopulations:
        try:
            idColorV,=(np.where(listPop==subPopulation.origin))
            plt.plot([subPopulation.timeEmergence,subPopulation.timeEmergence],[subPopulation.location,subPopulation.origin.location],color=colors[idColorV[0]],linestyle='--', linewidth=1.5)
        except:
            print("origin:",subPopulation.origin)
        
        idColor,=(np.where(listPop==subPopulation))
        plt.plot([subPopulation.timeEmergence,subPopulation.timeExtinction],[subPopulation.location,subPopulation.location],color=colors[idColor[0]], linewidth=1.5)
        
    #---- Add margins
    axes = plt.gca()
    axes.set_ylim((axes.get_ybound()[0] - 0.1), (axes.get_ybound()[1] + 0.1) )  
    
    plt.show()


def plotPESX(PES,tsim,colors,listPop):
    
    plt.figure('PES')
    
    subPopulations=[]
    for pop in PES:
        subPopulations.extend(pop.popComposition)
    
    subPopulations=set(subPopulations)
    
    x0 = listPop[0].xi
    
    for subPopulation in subPopulations:
        
        #vertical line
        try:
            idColorV,=(np.where(listPop==subPopulation.origin))
            formatLine=':'
            plt.plot([subPopulation.timeEmergence,subPopulation.timeEmergence],[subPopulation.location,subPopulation.origin.location],color=colors[idColorV[0]],linestyle=formatLine, linewidth=1.5)
        except:
            print("origin:",subPopulation.origin)   
        
        #---- hoirizontal line: trait style depends on x
        if subPopulation.xi == x0:          
            idColor,=(np.where(listPop==subPopulation))
            formatLine = '-'
            plt.plot([subPopulation.timeEmergence,subPopulation.timeExtinction],[subPopulation.location,subPopulation.location],color=colors[idColor[0]], linewidth=1.5,linestyle=formatLine)
        
        else:            
            idColor,=(np.where(listPop==subPopulation))
            formatLine = '--'
            plt.plot([subPopulation.timeEmergence,subPopulation.timeExtinction],[subPopulation.location,subPopulation.location],color=colors[idColor[0]], linewidth=1.5,linestyle=formatLine)

        
    #---- Add margins
    axes = plt.gca()
    axes.set_ylim((axes.get_ybound()[0] - 0.1), (axes.get_ybound()[1] + 0.1) )  
    
    plt.show()





def plotGeneralRecur(tree,y,k,listPop, colors):
    """
        Plots a coalescent tree
    """
    
    plt.figure('coalescent')
           
    #---- Horizontal line: last event to previous one etc
    for env in tree.subPopulations:
        idColor,=(np.where(listPop==env.subPopEnv))
        plt.plot([env.tOEnv,env.tfEnv],[y, y], color=colors[idColor[0]], linewidth=1.0)
        
    if tree.left!=None and tree.right!=None:
        #---- Vertical line to join the left and right children (time = emergence of children; color = last x of the individual)
        envI=tree.subPopulations[0]
        idColor,=(np.where(listPop==envI.subPopEnv))
        plt.plot([envI.tfEnv,envI.tfEnv],[y,y+1.0/(2**k)], color=colors[idColor[0]], linewidth=1.0)
        
        #---- Draw the left and right children
        plotGeneralRecur(tree.left,y,k+1,listPop, colors)
        plotGeneralRecur(tree.right,y+1.0/(2**k),k+1,listPop, colors)




def plotGeneral(listcoal,tfin,listPop, colors):
    """
        Plots several coalescent trees
    """
    
    for i in range(len(listcoal)):
        plt.figure('coalescent')
        plotGeneralRecur(listcoal[i],i,1,listPop,colors)
        
    #---- Add margins
    axes = plt.gca()
    axes.set_ylim(-0.1, (axes.get_ybound()[1] + 0.1) )       

    plt.show()

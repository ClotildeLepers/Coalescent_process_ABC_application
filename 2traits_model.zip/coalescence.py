      
"""
            II Phylogeny of individuals conditionally to the PES:
            
                    backward time: coalescence of sampled individuals (tsim) into the common ancestor(s) (t0)
                    for the number of steps in the PES:
                        coalescence of individuals within branches for the length of the step
                        coalescence of all individuals of the mutant branch at the branching point
                        integration of the mutant common ancestor to its ancestral sub-population (modification of its trait value xi)
                    Returns the trees of the individuals living in the population at t0 (all individuals of the ancestral population do not necessarily have time to coalesce)
"""


import numpy as np
import random as rd
import time

import binaryTree as bt


def stepCoalBranch(tstep,t,ni,bi,sampleSubPopi,subPopi,tsim,nbCherries,sumCoalExternalBranchLength):
    """
        Coalescence of individuals within a sub-population (branch) until the previous mutant emergence
    
        Key arguments:
            ni, bi : demographic characteristics of the sub-population i
            sampledIndi : the individuals sampled in the sub-population i (each ind = an object binaryTree)
            t : initial time
            tstep: the time of the previous evolutionary event (mutant emergence, t0).
        
        Draw the time needed for two sampled individual to coalesce
        If the time before the evolutionary event is long enough:
            Merge two individual into their common ancestor
        Repeat until tstep is reached.
    """
    
    nbInd=len(sampleSubPopi)
    #---- If no individual of this sub-population was sampled => exit.
    if nbInd==0:
        return (sampleSubPopi,nbCherries,sumCoalExternalBranchLength)
    #---- If there is more than one sampled individual => coalescence
    elif nbInd>1:
        
        #---- Draw the time step before a coalescence
        #        (nbInd * (nbInd - 1))/2 => number of possible pairs
        #        1/(ni) => probability that two individuals share parents
        #        bi => birth rate (scaling the coalescent coefficient).
        tcoal=rd.expovariate((bi/(ni))*nbInd*(nbInd-1)/2)
        t=t-tcoal
        
        #---- Coalescence occurs (if it happens before the next evolutionary event)
        if t>tstep:
            #---- Choice of two individuals
            tobemergedtrees=rd.sample(sampleSubPopi,2)
            
            #---- Measure the length of the coalescent tree.
            if tobemergedtrees[0].tSampling == tsim:
                sumCoalExternalBranchLength += (tobemergedtrees[0].tSampling) - (t)
            if tobemergedtrees[1].tSampling == tsim:
                sumCoalExternalBranchLength += (tobemergedtrees[1].tSampling) - (t)
            
            #---- Removed sampled individuals from the population
            sampleSubPopi.remove(tobemergedtrees[0])
            sampleSubPopi.remove(tobemergedtrees[1])
            
            #---- The two individuals are replaced by a new individual (father of the two removed individuals)
            mergedTrees,nbCherries=bt.mergeTrees(tobemergedtrees[0],tobemergedtrees[1], t, subPopi,tsim,nbCherries)
            sampleSubPopi.append(mergedTrees)

            #---- Start again the coalescence (tstep is not reached).
            return(stepCoalBranch(tstep,t,ni,bi,sampleSubPopi,subPopi,tsim,nbCherries,sumCoalExternalBranchLength))
        
        
    #---- If all individuals coalesced or tstep is reached: update individuals informations
    for ind in sampleSubPopi:
        ind.tEmergence = tstep
        ind.subPopulations[-1].tOEnv=tstep
    
    return(sampleSubPopi,nbCherries,sumCoalExternalBranchLength)
    



def forceCoal(t,sampleSubPopi,subPopi,tsim,nbCherries,sumCoalExternalBranchLength):
    """
        Coalescence of every individuals of the sub-population: only one mutant individual creates a new sub-population
    """
    #---- While all individuals didn't coalesce: coalescence
    while len(sampleSubPopi)>1:
        
        #---- The two individuals are replaced by a new individual (father of the two removed individuals)
        mergedTrees,nbCherries=bt.mergeTrees(sampleSubPopi[1],sampleSubPopi[0], t, subPopi,tsim, nbCherries)
        
        #---- Measure the length of the coalescent tree.
        if sampleSubPopi[0].tSampling == tsim:
            sumCoalExternalBranchLength += (sampleSubPopi[0].tSampling) - (t)
        if sampleSubPopi[1].tSampling == tsim:
            sumCoalExternalBranchLength += (sampleSubPopi[1].tSampling) - (t)
        
        # Remove [1] first (the cell index [0] is still the good one)
        sampleSubPopi.remove(sampleSubPopi[1])
        sampleSubPopi.remove(sampleSubPopi[0])
        sampleSubPopi.append(mergedTrees)
    
    return(sampleSubPopi,nbCherries,sumCoalExternalBranchLength)


def findSubPopID(subPop, sampledInd):
    """
        Finds the place of the sub-population in the list of sampled individuals
    """
    for pop in range(len(sampledInd)):
        if len(sampledInd[pop])>0:
            if sampledInd[pop][0].subPopulations[-1].subPopEnv == subPop:
                idSubPop = pop
                break
    
    try:
        return idSubPop
    except:
        return None
        

def coalStep(PES,currentT,sampledInd,bfun,clock0, popTsim, tsim, timeExceeded,nbCherries=0,sumCoalExternalBranchLength =0,listMRCApop=[]):
    """
        Coalescence of individuals through the PES.
        
        During each step of the PES: 
            coalescence of individuals within sub-populations
            time of mutant emergence: coalescence of all the individuals of the mutant sub-population (one mutant ancestor)
            Reassignment of the mutant individual to its ancestral population
    """
    timeExceeded = (float(time.clock() - clock0) > 20)
    if(timeExceeded):
        return  (sampledInd,timeExceeded)
    
    
    
    #---- Informations on the sub-populations from the current population
    currentPop=PES[-1]
    tstep = currentPop.t0
    x = currentPop.traits
    n = currentPop.densities
    popComp = currentPop.popComposition
    
    #---- Coalescence within sub-population:
    for pop in range(len(sampledInd)):
        if len(sampledInd[pop])>0:
            subPopID = np.where(np.array(popComp)==sampledInd[pop][0].subPopulations[-1].subPopEnv)
            subPopID=subPopID[0][0]
          
            
            #---- Update environmental data (densities...)
            for ind in sampledInd[pop]:
                # put back the emergence time
                ind.tEmergence=currentT
                # update the environmental data: the current environment starts at currentT, and the previous one ends at currentT
                ind.subPopulations[-1].tOEnv=currentT
                ind.addEnv(bt.EnvironmentStep(currentT, popComp[subPopID], popComp[subPopID].xi,popComp[subPopID].location, n[subPopID]))
                

            #---- Coalescence of individuals within branch
            sampledInd[pop],nbCherries,sumCoalExternalBranchLength=stepCoalBranch(tstep,currentT,n[subPopID],bfun(x[subPopID]),sampledInd[pop],popComp[subPopID],tsim,nbCherries,sumCoalExternalBranchLength)
       
    #---- If not already at the root : prepare the next step
    if currentPop.newSubPop.origin != None:
        #---- Find the individuals of the branch that emerged at tstep
        mutantAncestor=[]
        iMut=findSubPopID(currentPop.newSubPop, sampledInd)
        
        if iMut!=None:
            #---- Coalescence of all individuals of the mutant branch (one mutant creates the branch)
            mutantAncestor,nbCherries,sumCoalExternalBranchLength=forceCoal(tstep,sampledInd[iMut], currentPop.newSubPop, tsim, nbCherries,sumCoalExternalBranchLength)
                        
            #---- Remove the the mutant sub-population.
            sampledInd.remove(sampledInd[iMut])
            
            #---- Add the mutant to its previous sub-population and save its emergence time (MRCA of the sub-pop)
            if len(mutantAncestor)>0:
                #---- Add its new environment to the mutant (n = 0, will be corrected at the next coalStep.)
                #     newSubPop must be added to mutant, otherwise if the mutant is alone in the sub-population => no way to now its environment.
                mutantAncestor[0].addEnv(bt.EnvironmentStep(tstep, currentPop.newSubPop.origin, currentPop.newSubPop.origin.xi,currentPop.newSubPop.origin.location, 0))
                
                listMRCApop = np.append(listMRCApop, [currentPop.newSubPop.xi,currentPop.newSubPop.location,tsim-currentPop.newSubPop.timeEmergence ,tsim-currentPop.newSubPop.timeExtinction,tsim-mutantAncestor[0].tSampling])
                
                iAncestor=findSubPopID(currentPop.newSubPop.origin, sampledInd)              
                if iAncestor!=None:
                    sampledInd[iAncestor].append(mutantAncestor[0])
                #---- If the mutant is the only individual of the parent sub-population: create it
                else:
                    sampledInd.append([mutantAncestor[0]])
#              
        PES.remove(currentPop)
        
        
        #---- Coalescence of the previous step
        return(coalStep(PES,tstep,sampledInd,bfun,clock0, popTsim, tsim, timeExceeded,nbCherries,sumCoalExternalBranchLength,listMRCApop))
    

    
    return(sampledInd,timeExceeded,nbCherries,sumCoalExternalBranchLength,listMRCApop)

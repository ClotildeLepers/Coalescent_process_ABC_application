
"""
            Ia/Ib Emergence of a new mutation :
               
                    Ia : time step between mutation
                    Ib : trait value of the mutant
"""


import numpy as np
import random as rd


def timestep(p):
    """
        Returns a random variable drawn from an exponential distribution of parameter p
    
        e.g. returns the time needed for a mutant to emerge in a sub-population (depends of the birth rate in the sub-population)
    """
    return rd.expovariate(p)



# # # def gaussianMutation(xi,sig=1):
# # #     """
# # #         Returns a random variable from a Normal distribution (mean xi, standard deviation sig)
# # #     
# # #         e.g. returns the mutant trait value xmut (drawn around the parent sub-population trait value xi) 
# # #     """
# # #     return(rd.normalvariate(xi,sig))



def truncatedGaussianMutation(xi,sig=1,a=-2,b=2):
    """
        Returns a random variable from a truncated Normal distribution (mean xi, standard deviation sig, min a, max b)
     
        e.g. returns the mutant trait value xmut (drawn around the parent sub-population trait value xi) 
    """
    xmut=a-1
    while xmut<=a or xmut>=b:
        xmut=rd.normalvariate(xi,sig)
    return(xmut)



def survival(xmut,locMut,loc,n,bmut,dmut,etamut,Cfun):
    """
        Returns the probability for a mutant to reach the quasi-deterministic phase.
        
        Returns the mutant (trait xmut) growth rate in the resident population (traits x, densities n) divided by bmut
        (or 0 if the mutant has a negative growth rate).
    """
    nbSubPop=np.size(n)
    
    #---- Competition suffered by one individual with trait xmut (sum of: C(xmut,xi) ni )
    comp=0
    for i in range(nbSubPop):
        comp=comp+Cfun(locMut-loc[i])*n[i]
    
    #---- probability for a mutant to reach the quasi-deterministic phase
    probaSurvival=max(((bmut-dmut-etamut*comp)/bmut),0)
    return(probaSurvival)


def stepMutation(x,loc,n,bfun, dfun,etafun,Cfun,pxb01,pxb10,pLoc,sigLoc,minLoc,maxLoc,tmax):
    """
        Returns the mutation characteristics.
        
        Returns the time step needed to produce a successful mutant (with density exceeding the threshold allowing deterministic approximation)
                the mutant trait value
                the trait and identity of the sub-population that produced the mutant 
    """
    proba=0
    tirage=1
    tstep=0
    tTires=np.ones(len(n))
    
    #---- As long as a successful mutant hasn't emerged
    #     (i.e. no mutant has reached the density threshold allowing deterministic dynamic approximation)
    while tirage>proba and tstep<tmax+1:
        
        #---- For each sub-population, draw the time step before the emergence of a mutant
        #     (depends on the realized birth rate in the sub-pop: birth rate and density)
        for i in range (len(n)):
            tTires[i]=timestep(n[i]*bfun(x[i])*pLoc)
        
        #---- Mutant emerges in the sub-pop (ip) that has the shorter time step (tmin)
        tmin = min(tTires)
        ip = np.argmin(tTires)
        
        #---- Add the time step for this mutant to the total time before a successful emergence
        #     (sum up times steps for unsuccessful mutants + the time step for the successful one)
        tstep=tstep+tmin

# # #         #---- Draw the mutant location (Normal distribution) (not truncated!!!)
# # #         locMut=gaussianMutation(loc[ip],sigMut)
        
        #---- Draw the mutant location (truncated Normal distribution)
        locMut=truncatedGaussianMutation(loc[ip],sigLoc, minLoc, maxLoc)
        
        transition = 0
        #---- change of trait in the new population (nomads => settled)
        xmut = x[ip]
        if x[ip] == 0:
            tirageX=rd.uniform(0,1)
            if tirageX < pxb01:
                xmut = 1
                transition = 1
            else:
                xmut = 0

        #---- change of trait in the new population (settled => nomads) : add if necessary
        elif x[ip] == 1:
            tirageX=rd.uniform(0,1)
            if tirageX < pxb10:
                xmut = 0
            else:
                xmut = 1        
# # #
# # #         #---- change of trait in the new population (settled <=> nomads; symetric transitions)
# # #         tirageX=rd.uniform(0,1)
# # #         if tirageX > pxb01:
# # #             xmut =  x[ip]
# # #         else:
# # #             if x[ip] == 0:
# # #                 xmut = 1
# # #             else:
# # #                 xmut = 0


        #---- Determine the probability that the mutant survives (its fitness in the resident population)
        #     (i.e. proba that its density will exceed the threshold allowing deterministic dynamic approximation)
        proba=survival(xmut,locMut,loc,n,bfun(xmut),dfun(xmut),etafun(xmut),Cfun)
        
        #---- The mutant survives if tirage < proba.
        tirage=rd.uniform(0,1)
        
        
    return (tstep,xmut,locMut,ip,transition)



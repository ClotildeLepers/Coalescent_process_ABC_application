
"""
            Give values to the parameters: random values or fixed ones
"""


import numpy as np
import random as rd




def meanfield(x,mean):
    return(mean)
 
def curryMeanfield(mean):
    """
        Nested function (independent of the trait xi).  Will be used with mean = d and mean = eta.
        Gives the values of death rate (dfun(xi) = d) and competition coefficient (etafun(xi) = eta)
    """
    return lambda x:meanfield(x,mean)
 
def gaussianKernel(x,sig):
    return(np.exp(-(x/sig)**2)/2)
 
def curryGaussian(sig):
    """
        Nested function. Will be used with sig = b and sig = C.
        Calculates the values of birth rate (bfun(xi)) and competition (Cfun(xi-xj)) depending of the trait xi
    """
    return lambda x: gaussianKernel(x,sig)

def gaussianKernelC(x,sigC):
    return(np.exp(-(x/sigC)**2)/2 + (1/100))

def funcC(sigC):
    return lambda x: gaussianKernelC(x,sigC)

def twoValFunction(val0,val1):
    return lambda x: (x*val1 + (1-x)*val0)


def randomParametersb0b1():
    """ Draw random parameters """
    #---- transition from state 0 (nomads) to state 1 (settled pop) when a new pop is established
    pxb01 = rd.uniform(0.1,0.3)
    pxb10 = rd.uniform(0.1,0.3)
    #---- death rate
    dC=1.
    dfun=curryMeanfield(dC)         #---- Returns d(xi)=d death rate    
    #---- birth rate of nomad pop
    b0 = np.random.normal(2.062, 1,1)[0]
    while b0<dC :
        b0=np.random.normal(2.062, 1,1)[0]
    #---- birth rate of settled pop
    b1 = np.random.normal(2.062, 1,1)[0]
    while b1<b0 :
        b1=np.random.normal(2.062, 1,1)[0]
    #---- Returns b(xi) birth rate depending on trait value: b0 or b1
    bfun=twoValFunction(b0,b1)
    #---- creation of new pop: transition rate
    pLoc=rd.uniform(0.007,0.008)
    #---- space between pop
    sigLoc = rd.uniform(0.19,100)
    minLoc = 55
    maxLoc = 80
    #---- competition coefficient eta(xi)=eta0 or eta1
    etaC0=rd.uniform(0.001,0.1)
    etaC1=rd.uniform(0.001,0.1)
    etafun=twoValFunction(etaC0,etaC1)
    #---- effect of space on competition
    sigC=rd.uniform(0.01,5)
    Cfun=curryGaussian(sigC)
    
    #---- time of the simulation
    tsim=rd.expovariate(1/6e2)
    
    #---- neutral mutation rate
    theta=rd.uniform(0.1,1)
    
    
    return(pxb01,pxb10,b0,b1,bfun,pLoc,sigLoc,minLoc,maxLoc,etaC0,etaC1,etafun,sigC,Cfun,dC,dfun,tsim,theta)


def randomParametersEqualb():
    """ Draw random parameters """
    #---- transition from state 0 (nomads) to state 1 (settled pop) when a new pop is established
    pxb01 = rd.uniform(0.1,0.3)
    pxb10 = rd.uniform(0.1,0.3)
    #---- death rate
    dC=1.
    dfun=curryMeanfield(dC)         #---- Returns d(xi)=d death rate
    #---- birth rate of nomad pop
    b0 = np.random.normal(2.062, 1,1)[0]
    while b0<dC :
        b0=np.random.normal(2.062, 1,1)[0]
    #---- birth rate of settled pop
    b1 = b0
    #---- Returns b(xi) birth rate depending on trait value: b0 or b1
    bfun=twoValFunction(b0,b1)
    #---- creation of new pop: transition rate
    pLoc=rd.uniform(0.007,0.008)
    #---- space between pop
    sigLoc = rd.uniform(0.19,100)
    minLoc = 55
    maxLoc = 80
    #---- competition coefficient eta(xi)=eta0 or eta1
    etaC0=rd.uniform(0.001,0.1)
    etaC1=rd.uniform(0.001,0.1)
    etafun=twoValFunction(etaC0,etaC1)
    #---- effect of space on competition
    sigC=rd.uniform(0.01,5)
    Cfun=curryGaussian(sigC)
    
    #---- time of the simulation
    tsim=rd.expovariate(1/6e2)
    
    #---- neutral mutation rate
    theta=rd.uniform(0.1,1)
    
    
    return(pxb01,pxb10,b0,b1,bfun,pLoc,sigLoc,minLoc,maxLoc,etaC0,etaC1,etafun,sigC,Cfun,dC,dfun,tsim,theta)


def fixedParameters():
    """ Define fixed parameters """
    #---- transition from state 0 (nomads) to state 1 (settled pop) when a new pop is established
    pxb01 = 0.25
    pxb10 = 0.25
    #---- birth rate of nomad pop
    b0 = 2.13
    #---- birth rate of settled pop
    b1 = 2.28
    #---- Returns b(xi) birth rate depending on trait value: b0 or b1
    bfun=twoValFunction(b0,b1)
    #---- creation of new pop: transition rate
    pLoc=0.0005
    #---- space between pop
    sigLoc = 10
    minLoc = 55
    maxLoc = 80
    #---- competition coefficient eta(xi)=eta0 or eta1
    etaC0=0.045
    etaC1=0.05
    etafun=twoValFunction(etaC0,etaC1)
    #---- effect of space on competition
    sigC=2.5
    Cfun=curryGaussian(sigC)
        #---- death rate
    dC=0.
    dfun=curryMeanfield(dC) #---- Returns d(xi)=d death rate
    #---- time of the simulation
    tsim=150
    #---- neutral mutation rate
    theta=0.6
    
    
    return(pxb01,pxb10,b0,b1,bfun,pLoc,sigLoc,minLoc,maxLoc,etaC0,etaC1,etafun,sigC,Cfun,dC,dfun,tsim,theta)


def dataRandomParameters():
    """ Define some fixed parameters from data. Randomly draw the others"""    
    pxb01 = rd.uniform(0.1,0.4)
    pxb10 = rd.uniform(0.1,0.4)
    #---- birth rate of nomad pop
    b0 = 2.13
    #---- birth rate of settled pop
    b1 = 2.28
    #---- Returns b(xi) birth rate depending on trait value: b0 or b1
    bfun=twoValFunction(b0,b1)
    
    
    #---- creation of new pop: transition rate
    pLoc=rd.uniform(0.001,0.01)
    #---- space between pop
    sigLoc = rd.uniform(0.1,100)
    minLoc = 55
    maxLoc = 80
    #---- competition coefficient eta(xi)=eta0 or eta1
    etaC0=rd.uniform(0.01,0.1)
    etaC1=rd.uniform(0.01,0.1)
    etafun=twoValFunction(etaC0,etaC1)
    #---- effect of space on competition
    sigC=rd.uniform(0.01,3)
    Cfun=funcC(sigC)
    
    
    #---- death rate
    dC=0.
    dfun=curryMeanfield(dC)         #---- Returns d(xi)=d death rate
    
    #---- time of the simulation
    tsim=rd.expovariate(1/6e2)
    
    #---- neutral mutation rate
    theta=rd.uniform(0.1,1)
    
    
    return(pxb01,pxb10,b0,b1,bfun,pLoc,sigLoc,minLoc,maxLoc,etaC0,etaC1,etafun,sigC,Cfun,dC,dfun,tsim,theta)


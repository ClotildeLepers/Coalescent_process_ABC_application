"""
            class StatisticsPop: stores all the statistics on neutral markers of the populations
"""
import numpy as np

class StatisticsPop():
    
    def __init__(self):
        
        #---- measured in pesStatistics 
        self.nbEvents=None
        self.nbSubPop=None
        self.meanN=None
        self.varN=None
        self.meanXPop=None
        self.varXPop=None
        self.meanLocPop=None
        self.varLocPop=None
        self.meanXInd = None
        self.varXInd = None
        self.sackinIS = None
        self.meanLocInd=None
        self.varLocInd = None
        self.varLocIntraX = np.nan
        self.varLocInterX = np.nan
        
            
            
        #---- measured in sampleStatistics
        self.nbSubPopSampled = None
        self.varNrelSample = None
        self.meanXpopSample = None
        self.varXpopSample = None
        self.meanLocPopSample = None
        self.varLocPopSample = None
        self.meanXindSample = None
        self.meanLocIndSample = None
        self.varXindSample = None
        self.varLocIndSample = None
        
        #---- measured in neutralStatistics
        self.meanNbAllleles = None
        self.meanMIndex = None
        self.meanVarAlleles = None
        self.meanGeneDiversity = None
        self.meanUnbiasedGeneDiversity = None
        
        self.meanNeiDa = np.nan
        self.meanNeiDs = np.nan
        self.meanDeltaMu = np.nan
        self.meanFst = np.nan
        self.meanWeightedNeiDa = np.nan
        self.meanWeightedNeiDs = np.nan
        self.meanWeightedDeltaMu = np.nan
        self.meanWeightedFst = np.nan
        
        self.varNeiDa = np.nan
        self.varNeiDs = np.nan
        self.varDeltaMu = np.nan
        self.varFst = np.nan
        self.varWeightedNeiDa = np.nan
        self.varWeightedNeiDs = np.nan
        self.varWeightedDeltaMu = np.nan
        self.varWeightedFst = np.nan
        
       
        self.NeiDa01 = np.nan
        self.NeiDs01 = np.nan
        self.DeltaMu01 = np.nan
        self.Fst01 = np.nan
        self.WeightedNeiDa01 = np.nan
        self.WeightedNeiDs01 = np.nan
        self.WeightedDeltaMu01 = np.nan
        self.WeightedFst01 = np.nan
    

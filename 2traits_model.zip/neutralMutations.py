
"""
            III Neutral locus mutation conditionally to the phylogeny
            
                    Simulation of microsatellite mutation => at each mutation gain or loss of a repeat of the motif.
                    Forward time: mutations transmitted from the common ancestor to the sampled individuals.
"""

import random as rd
import binaryTree as bt


def microSatelliteMut():
    """
        Randomly determine if the microsatellite gains or losses a repeat of its motif.
        
        Simplest model of mutation: gain/loss of one repetition at a time, with equal probability.
    """
    return(rd.choice([-1,1]))


    
def mutStep(tlim,tinitial,rate,currentMarker,nbNeutralLocus):
    """
        Successive mutations between events occurring to the individual
        
        Draws the time before mutation.
        If the mutation can occur before the next event => gain or loss of a motif repeat.
        Returns the final number of repeats and the time of the mutation and lineage of the individual.
    """
    
    
    for i in range(nbNeutralLocus):
        t=tinitial
        #---- Time between mutations drawn from an exponential distribution of parameter b(xi) * theta
        #         => b(xi) must be constant.
        t=t+rd.expovariate(rate)
    
        #---- Successive mutations until an event occurs to the individual 
        while t<tlim:
            #---- Gain or loss of a motif repeat (randomly drawn)
            currentMarker[i] = currentMarker[i] + microSatelliteMut()
            #---- Draw the next time before mutation
            t=t+rd.expovariate(rate)
        
    return(currentMarker)



def mutBranch(ind,theta,bfun,currentMarker,nbNeutralLocus):
    """
        Mutations of the microsatellite locus for one individual from birth to the time of its descendant production.
        
        Key parameters:
            treeRoot: root of the individual
                (time of emergence, [(time of the most recent event, trait, density),
                                      ... ,
                                     (time of the oldest event, trait, density)])
            currentMarker: nb of motif repeats at the time of emergence of treeRoot (in its lineage y)
    """
    #---- Extract the time steps:
    #        t time of emergence of the individual
    #        u all events during the lifetime of the individual
    #            reverse u (older event first) => mutation between creation and 1st event; 1st and 2nd etc
    t = ind.tEmergence
    environmentsSubPop = ind.subPopulations[::-1]
    #---- For each time step:
    #        define the rate of mutation (depends on xi during the time step)
    #        let mutations occur for the length of the time step
    for env in environmentsSubPop:
        tlim = env.tfEnv
        rate = bfun(env.xEnv)*theta
        currentMarker=mutStep(tlim,t,rate,currentMarker,nbNeutralLocus)        
        t=tlim
    
    return(currentMarker)



def mutTree(tree,theta,bfun,nbNeutralLocus,currentMarker=None):
    """
        Mutation events for a complete tree: from the common ancestor to the leaves (sampled individuals).
        
        1) Get the mutation events in the common ancestor, save its nb of motif repeats and the times of mutations
        2) From the nb of motif repeats of the parent, get the mutation events in its two descendants => divergence
                independent mutation events for the two individuals
        3) For the two descendants => repeat 2) until there is no descendant.
        
        Returns: the nb of motif repeats at tsim (end of the tree) for each sampled individual of the tree
                 the time of the mutation events and the lineage in which it occurs.
    """
    listNeutral=[]
    listSampledTrees=[]
    for i in range(nbNeutralLocus):
        listNeutral.append([])
    
    if currentMarker == None:
        currentMarker=[]
        for i in range(nbNeutralLocus):
            currentMarker.append(0.0)
    
    
    #---- Mutations through the lifetime of the individual
    currentMarker=mutBranch(tree,theta,bfun,currentMarker,nbNeutralLocus)
    tree.NeutralMarkers = list(currentMarker)
    
    #---- Find its descendants
    if tree.left==None:
        listSampledTrees.append(tree)
        
        for i in range(nbNeutralLocus):
            listNeutral[i]=[currentMarker[i]]
        
    else:
        
        #---- Simulate the mutations independently for left and right child (allow divergence)
        leftMarker,leftTree=mutTree(tree.left,theta,bfun,nbNeutralLocus,tree.NeutralMarkers)
        rightMarker,rightTree=mutTree(tree.right,theta,bfun,nbNeutralLocus,tree.NeutralMarkers)
        
        listSampledTrees.extend(leftTree)
        listSampledTrees.extend(rightTree)
        
        for i in range(nbNeutralLocus):
            listNeutral[i].extend(leftMarker[i])
            listNeutral[i].extend(rightMarker[i])
        
    return(listNeutral,listSampledTrees)



def mutlistTree(listTrees,theta,bfun,nbNeutralLocus=1):
    """
        Mutation events for all the lineages present at t0 (all individuals that did not coalesce)
    """
    listNeutral=[]
    for i in range(nbNeutralLocus):
        listNeutral.append([])

    listSampledTrees=[]
    for i in range(len(listTrees)):
        v,sampledTrees=mutTree(listTrees[i],theta,bfun,nbNeutralLocus)


        listSampledTrees.extend(sampledTrees)    
        
        for j in range(nbNeutralLocus):
            listNeutral[j].extend(v[j])


    return(listNeutral,listSampledTrees)
    

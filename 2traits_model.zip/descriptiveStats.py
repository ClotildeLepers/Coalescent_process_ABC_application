
"""
            Descriptive statistics on the neutral locus
            
                    number of alleles (gives an idea of the population size)
                    variance of the alleles
                    M index (gives an idea of bottleneck occurrences)
                    genetic diversity
"""

import numpy as np
import copy
import math
import saveStatistics as saveS
#LS#from scour import numBytesSavedInTransforms
# from scipy.cluster.hierarchy import weighted
# import time


def neutralStatistics(sampledTrees,listNeutrals,statVal):
    """
        Calculate statistics on the neutral markers of the sampled individuals
        --------------------------------------------------------------------------------------------------------------------------
        
        ---------------------------------------------------------------
        1) Statistics measured on each locus and averaged
        ---------------------------------------------------------------
        
        number of alleles per locus: measure of allelic diversity
                        => useful to infer population size through time
                        => drift leads to the loss of alleles in small populations        
        
        M index: detection of reductions in population size (their intensity and duration)
                        M index = nb alleles / range in allele size 
                        = the average percentage of intermediate allelic states that are occupied
                        => The lower the M index, the more the population has lost possible alleles
                        (in huge population, alleles should exist throughout the range size)
        
        Use of allele number and M index:
            low number of alleles and low M-index: recent reduction of size 
            low number of alleles but high M-index: small population for a long time
            
        Allele variance: measure of allelic diversity
        
        Gene Diversity: expected difference between each couple of individuals in the population
            For each couple of two individuals in the population, sum of the difference of motif repeat
            
        Unbiased Gene Diversity: average difference between two individuals in the population
            Average difference of motif repeats between two individuals randomly drawn in the population
        
        
        ---------------------------------------------------------------
        2) Genetic distance between the populations
        ---------------------------------------------------------------
        Fst:  correlation of individuals within sub-populations compared to total correlation
        (delta mu)2
        Da
        Ds
        
        + these statistics weighted by the density of the populations
        
        ---------------------------------------------------------------
        3) Genetic distance between sub-populations with the same trait
        ---------------------------------------------------------------
        Same statistics than 2) but considering all sub-populations with the same trait are one group
        
    """
    #-------------------------------------------------------------------------------------
    #----       Determine the frequency of each allele in each sub-populations        ----
    #-------------------------------------------------------------------------------------
 
    allelesID=[]
    allelesNb=[]
    varAlleles=[]
    mIndex = []
    geneDiversity=[]
    unbiasedGeneDiversity=[]
    emptyFrequences=[]
    
    #---- On each locus
    for locusI in listNeutrals:
        
        #-------------------------------------------------------------------------------------
        #----      Measure the diversity at the population level (for each locus)         ----
        #-------------------------------------------------------------------------------------   
        
        #---- Identity of the markers (number of repeats at the microsatellite locus)
        allelesID.append(list(set(locusI)))
        #---- Variance in the marker lengths
        varAlleles.append(np.var(allelesID[-1]))
        #---- Number of alleles
        allelesNb.append(len(allelesID[-1]))
        #---- M index: nb alleles / range in allele size
        if(len(allelesID[-1])>1):
            mIndex.append(allelesNb[-1] / float(max(allelesID[-1]) - min(allelesID[-1])))
        else :
            mIndex.append(np.nan)
        
        #---- number of sampled individuals
        nbInd=float(len(locusI))
   
        #---- Frequency of each allele at this locus at the population level
        freq=[0]*allelesNb[-1]
        for i in range(allelesNb[-1]):
            freq[i]=(locusI.count(allelesID[-1][i]))/nbInd
    
        #---- Gene diversity:
        #        sum of : dissimilarity coefficient * frequencies
        #            dissimilarity coefficient (difference in their number of motif repeats)
        #            cumulative difference between individuals
        geneDiv=0.0
        for i in range(allelesNb[-1]):
            for j in range(allelesNb[-1]):
                geneDiv += abs(allelesID[-1][i] - allelesID[-1][j]) * freq[i] * freq[j]
    
        geneDiversity.append(geneDiv)
        
        #---- Unbiased gene diversity: average on the sampled individuals.
        unbiasedGeneDiv = (nbInd/(nbInd-1))*geneDiv
        unbiasedGeneDiversity.append(unbiasedGeneDiv)
        
           
        #---- Empty structure : for each locus, size = number of alleles.
        #            It will be used for each sub-population, and filled with the frequency of each allele
        emptyFrequences.append([0.0]*allelesNb[-1])
        

    #---- Store the statistics on neutral markers for the whole population
    statVal.meanNbAllleles = np.mean(allelesNb)
    statVal.meanMIndex = np.nanmean(mIndex)
    statVal.meanVarAlleles = np.mean(varAlleles)
    statVal.meanGeneDiversity = np.mean(geneDiversity)
    statVal.meanUnbiasedGeneDiversity = np.mean(unbiasedGeneDiversity)
    
    
    
    
    
    
    #-------------------------------------------------------------------------------------
    #----          Measure the distance between each pair of sub-population           ----
    #----            Measure the distance between sub-populations x0 / x1             ----
    #-------------------------------------------------------------------------------------
    
    #---- Determine the number of individuals bearing each allele in each population
    listPop=[]
    nPop=[]
    ntot = 0.0
    neutralFreqPop=[]
    nbIndSampledPop=[]
    
    listX=[]
    nX=[]
    neutralFreqX=[]
    nbIndSampledX=[]
    
    
    for ind in sampledTrees:
        popI = ind.subPopulations[0].subPopEnv
        xI = ind.subPopulations[0].xEnv
        
        
        if not(popI in listPop):
            listPop.append(popI)
            nbIndSampledPop.append(0.0)
            shape=copy.deepcopy(emptyFrequences)
            neutralFreqPop.append(shape)  
            nPop.append(ind.subPopulations[0].densityEnv)
            ntot+=ind.subPopulations[0].densityEnv
        
            if not(xI in listX):
                listX.append(xI)
                nbIndSampledX.append(0.0)
                shape=copy.deepcopy(emptyFrequences)
                neutralFreqX.append(shape)  
                nX.append(ind.subPopulations[0].densityEnv)
            else:
                nX[listX.index(xI)]+= ind.subPopulations[0].densityEnv
    
    
    #---- Determine the frequency of each allele per population:
    for ind in sampledTrees:
            
        neutrals = ind.NeutralMarkers
        
        popI = ind.subPopulations[0].subPopEnv
        idPop = listPop.index(popI)
        nbIndSampledPop[idPop]+=1
            
        xI = ind.subPopulations[0].xEnv
        idX = listX.index(xI)
        nbIndSampledX[idX]+=1
            
        for locus in range(len(neutrals)):
            allele=neutrals[locus]
            idA = allelesID[locus].index(allele)
            neutralFreqPop[idPop][locus][idA]+=1
            neutralFreqX[idX][locus][idA]+=1

        
        
    for idPop in range(len(neutralFreqPop)):
        for locus in range(len(neutralFreqPop[idPop])):
            neutralFreqPop[idPop][locus]=[i/float(nbIndSampledPop[idPop]) for i in neutralFreqPop[idPop][locus]]
    
    for idX in range(len(neutralFreqX)):
        for locus in range(len(neutralFreqX[idX])):
            neutralFreqX[idX][locus]=[i/float(nbIndSampledX[idX]) for i in neutralFreqX[idX][locus]]
            
    #---- Normalization of the number of repetitions (all positives)
    minAlleles = 0.0
    for locus in allelesID:
        minAlleles=min(minAlleles, min(locus))
    minAlleles=abs(minAlleles)+1
            
    allelesNormalized=[]
    for locus in allelesID:
        allelesNormalized.append([allele + minAlleles for allele in locus])
            
    nbLocus=len(allelesID)
        
        
            
    #---- if there is more than one sub-population
    #            measure between sub-population statistics for each pair (otherwise, remains NA)
    if (len(listPop)) > 1:
        #------------------------------------------------------------------------------
        #---- For each pair of sub-populations, measure Da, (delta mu)2, Ds, and Fst
        #------------------------------------------------------------------------------
        neiDa=[]
        deltaMu=[]
        neiDs=[]
        fst=[]
        weightedDa=[]
        weightedDeltaMu=[]
        weightedDs=[]
        weightedFst=[]
            
            
        for idPopA in range(len(neutralFreqPop)):
            for idPopB in range((idPopA+1),len(neutralFreqPop)):
    
                sumAA=0.0        
                sumBB=0.0
                sumAB=0.0
                
                neiDaAB=0.0
                deltaMuAB=0.0
                                    
                for idLocus in range(nbLocus):
                
                    muA=0.0
                    muB=0.0
                        
                    for idA in range(allelesNb[idLocus]):                
                        neiDaAB+=math.sqrt(neutralFreqPop[idPopA][idLocus][idA] * neutralFreqPop[idPopB][idLocus][idA])
                    
                        muA += allelesNormalized[idLocus][idA] * neutralFreqPop[idPopA][idLocus][idA]
                        muB += allelesNormalized[idLocus][idA] * neutralFreqPop[idPopB][idLocus][idA] 
                            
                        sumAA += neutralFreqPop[idPopA][idLocus][idA] * neutralFreqPop[idPopA][idLocus][idA]
                        sumBB += neutralFreqPop[idPopB][idLocus][idA] * neutralFreqPop[idPopB][idLocus][idA]
                        sumAB += neutralFreqPop[idPopA][idLocus][idA] * neutralFreqPop[idPopB][idLocus][idA]
                        
                    deltaMuAB += (muA-muB) * (muA-muB)
                    
                neiDaAB/=float(nbLocus)
                neiDaAB=1-neiDaAB
                neiDa.append(neiDaAB)
                
                weightedDa.append( (nPop[idPopA] * nPop[idPopB] * neiDaAB)/float(ntot))
    
                deltaMuAB/=float(nbLocus)
                deltaMu.append(deltaMuAB)
                
                weightedDeltaMu.append((nPop[idPopA] * nPop[idPopB] * deltaMuAB)/float(ntot))
                    
                    
                sumAA/=float(nbLocus)
                sumBB/=float(nbLocus)
                sumAB/=float(nbLocus)
                    
                    
                #---- If there is no shared alleles between population, sumXY=0 => Ds = ln(0) => NA
                try:
                    neiDs.append( math.log(sumAB/(math.sqrt(sumAA*sumBB))) )
                    weightedDs.append((nPop[idPopA] * nPop[idPopB] * (math.log(sumAB/(math.sqrt(sumAA*sumBB))))/float(ntot)))
                except:
                    if sumAB == 0:
                        #---- missing value (will not affect the mean => biased because doesn't reflect the population at all)
                        neiDs.append(np.nan)
                        weightedDs.append(np.nan)
# # #                         #---- replace with a small sumXY (as if we missed some similar individuals during the sampling)
# # #                         neiDs.append( math.log(0.00001/(math.sqrt(sumXX*sumYY))) )
# # #                         weightedDs.append( math.log(0.00001/(math.sqrt(sumXX*sumYY))) )
                    else:
                        print("error neiDs")
       
                #---- If two populations have the exact same neutral composition sumXX = sumYY = sumXY = 1
                #        fst = 0/0 => 0
                try:
                    fst.append( (((sumAA + sumBB)/2.0)-sumAB)/(1-sumAB) )
                    weightedFst.append((nPop[idPopA] * nPop[idPopB] *  ((((sumAA + sumBB)/2.0)-sumAB)/(1-sumAB)))/float(ntot) )
                except:
                    if (sumAA == 1.0) & (sumBB == 1.0) &  (sumAB == 1.0):
                        fst.append(0.0)
                        weightedFst.append(0.0)
                    else:
                        print("error fst")
                        
        
        if (len(listPop)) > 2:
            statVal.meanNeiDa = np.nanmean(neiDa)
            statVal.meanNeiDs = np.nanmean(neiDs)
            statVal.meanDeltaMu = np.nanmean(deltaMu)
            statVal.meanFst = np.nanmean(fst)
            statVal.meanWeightedNeiDa = np.nanmean(weightedDa)
            statVal.meanWeightedNeiDs = np.nanmean(weightedDs)
            statVal.meanWeightedDeltaMu = np.nanmean(weightedDeltaMu)
            statVal.meanWeightedFst = np.nanmean(weightedFst)
            
            statVal.varNeiDa = np.nanvar(neiDa)
            statVal.varNeiDs = np.nanvar(neiDs)
            statVal.varDeltaMu = np.nanvar(deltaMu)
            statVal.varFst = np.nanvar(fst)
            statVal.varWeightedNeiDa = np.nanvar(weightedDa)
            statVal.varWeightedNeiDs = np.nanvar(weightedDs)
            statVal.varWeightedDeltaMu = np.nanvar(weightedDeltaMu)
            statVal.varWeightedFst = np.nanvar(weightedFst)
        
        else:
            statVal.meanNeiDa = neiDa[0]
            statVal.meanNeiDs = neiDs[0]
            statVal.meanDeltaMu = deltaMu[0]
            statVal.meanFst = fst[0]
            statVal.meanWeightedNeiDa = weightedDa[0]
            statVal.meanWeightedNeiDs = weightedDs[0]
            statVal.meanWeightedDeltaMu = weightedDeltaMu[0]
            statVal.meanWeightedFst = weightedFst[0]
                
    
    #---- if more than one sub-population and more than one trait                       
    #            measure between traits statistics for sub-populations x0 vs. x1
    if (len(listX) > 1):
        print("lenX > 1")           
        #------------------------------------------------------------------------------------
        #---- Difference for sub-populations with trait X0 -X1: Da, (delta mu)2, Ds, and Fst
        #------------------------------------------------------------------------------------
        if len(listX) > 2:
            print("error!!! x > 2")
                
        sum00=0.0        
        sum11=0.0
        sum01=0.0
                
        neiDa01=0.0
        deltaMu01=0.0
                                    
        for idLocus in range(nbLocus):
                
            mu0=0.0
            mu1=0.0
                        
            for idA in range(allelesNb[idLocus]):                
                neiDa01+=math.sqrt(neutralFreqX[0][idLocus][idA] * neutralFreqX[1][idLocus][idA])
            
                mu0 += allelesNormalized[idLocus][idA] * neutralFreqX[0][idLocus][idA]
                mu1 += allelesNormalized[idLocus][idA] * neutralFreqX[1][idLocus][idA] 
                            
                sum00 += neutralFreqX[0][idLocus][idA] * neutralFreqX[0][idLocus][idA]
                sum11 += neutralFreqX[1][idLocus][idA] * neutralFreqX[1][idLocus][idA]
                sum01 += neutralFreqX[0][idLocus][idA] * neutralFreqX[1][idLocus][idA]
                        
            deltaMu01 += (mu0-mu1) * (mu0-mu1)
                    
            neiDa01/=float(nbLocus)
            neiDa01=1-neiDa01
               
            weightedDa01 = ((nX[0] * nX[1] * neiDa01)/float(ntot))
    
            deltaMu01/=float(nbLocus)
                
            weightedDeltaMu01=((nPop[0] * nPop[1] * deltaMu01)/float(ntot))
                    
                    
        sum00/=float(nbLocus)
        sum11/=float(nbLocus)
        sum01/=float(nbLocus)
                    
                    
        #---- If there is no shared alleles between population, sumXY=0 => Ds = ln(0) => NA
        try:
            neiDs01=( math.log(sum01/(math.sqrt(sum00*sum11))) )
            weightedDs01=((nPop[0] * nPop[1] * (math.log(sum01/(math.sqrt(sum00*sum11))))/float(ntot)))
        except:
            if sum01 == 0:
                #---- missing value (will not affect the mean => biased because doesn't reflect the population at all)
                neiDs01=np.nan
                weightedDs01=np.nan
# # #                 #---- replace with a small sumXY (as if we missed some similar individuals during the sampling)
# # #                 neiDs.append( math.log(0.00001/(math.sqrt(sumXX*sumYY))) )
# # #                 weightedDs.append( math.log(0.00001/(math.sqrt(sumXX*sumYY))) )
            else:
                print("error neiDs01")
       
        #---- If two populations have the exact same neutral composition sumXX = sumYY = sumXY = 1
        #        fst = 0/0 => 0
        try:
            fst01 = ( (((sum00 + sum11)/2.0)-sum01)/(1-sum01) )
            weightedFst01 = ((nPop[0] * nPop[1] *  ((((sum00 + sum11)/2.0)-sum01)/(1-sum01)))/float(ntot) )
        except:
            print("sums = 0 fst01")
            if (sum00 == 1.0) & (sum11 == 1.0) &  (sum01 == 1.0):
                fst01 = (0.0)
                weightedFst01 = (0.0)
            else:
                print("error fst01")
                
        statVal.NeiDa01 = neiDa01
        statVal.NeiDs01 = neiDs01
        statVal.DeltaMu01 = deltaMu01
        statVal.Fst01 = fst01
        statVal.WeightedNeiDa01 = weightedDa01
        statVal.WeightedNeiDs01 = weightedDs01
        statVal.WeightedDeltaMu01 = weightedDeltaMu01
        statVal.WeightedFst01 = weightedFst01


    return statVal
    
    



def sampleStatistics(sampledInd,statVal):
    """
        Calculate statistics on the sampled individuals
            nbSubPopSampled: number of sampled sub-populations
            relativeAbundance: relative abundance variance between sampled sub-populations
            meanTraitSampledPop: mean trait of sampled sub-populations
            varTraitSampledPop: trait variance between sampled sub-populations
            meanTraitIndSampled: mean trait of sampled individuals (vary with density)
            varTraitIndSampled: trait variance between sampled individuals (vary with density)
    """
    
    nbSampledInd=0
    nbSubPopSampled = 0
    traitsSampled=[]
    locationSampled=[]
    
    meanTraitSampledInd=0.0
    meanLocSampledInd=0.0
    
    relativeAbundance=[]
    
    
    for sampleSubPop in sampledInd:
        
        nbSampledIndSubPop = len(sampleSubPop)
        nbSampledInd += nbSampledIndSubPop
        
        if nbSampledIndSubPop > 0:
            
            nbSubPopSampled += 1
            
            relativeAbundance.append(nbSampledIndSubPop)
            
            xi = sampleSubPop[0].subPopulations[0].xEnv
            locI = sampleSubPop[0].subPopulations[0].locEnv
            
            traitsSampled.extend([xi])
            locationSampled.extend([locI])   
                        
            meanTraitSampledInd+=(xi * nbSampledIndSubPop)
            meanLocSampledInd+=(locI * nbSampledIndSubPop)
    
    statVal.nbSubPopSampled = nbSubPopSampled
    
    relativeAbundance=[nbInd/float(nbSampledInd) for nbInd in relativeAbundance]
    statVal.varNrelSample=np.var(relativeAbundance)
    
    meanXpopSample = np.mean(traitsSampled)
    statVal.meanXpopSample = meanXpopSample
    
    statVal.varXpopSample = np.var(traitsSampled)
    
    meanLocPopSample = np.mean(locationSampled)
    statVal.meanLocPopSample=meanLocPopSample
    statVal.varLocPopSample = np.var(locationSampled)
    
    statVal.meanXindSample = meanTraitSampledInd/nbSampledInd
    statVal.meanLocIndSample = meanLocSampledInd/nbSampledInd
    
    varTraitSampledInd=[]    
    varLocSampledInd=[]
    for i in range(nbSubPopSampled):
        varTraitSampledInd.append([((relativeAbundance[i])*((abs((traitsSampled[i])-meanXpopSample))**2))])
        varLocSampledInd.append([((relativeAbundance[i])*((abs((locationSampled[i])-meanLocPopSample))**2))])
    statVal.varXindSample=np.mean(varTraitSampledInd)
    statVal.varLocIndSample=np.mean(varLocSampledInd)   

    return(statVal)


def pesStatistics(PES,statVal):
    """
        Calculate statistics on the PES.
            nbEvents: number of mutation events along the PES
            nbSubPop: number of coexisting sub-populations at tsim
            meanAbundance: mean abundance of the coexisting sub-populations at tsim
            varAbundance: variance of the abundance of the coexisting sub-populations at tsim
            meanTraitPop: mean trait x of the sub-populations
            varTraitPop: trait variance between sub-populations
            meanTraitInd: mean trait x of the individuals in all sub-populations (depends on densities)
            varTraitInd: variance between the traits of individuals in all sub-populations (depends on densities)            
    """
    statVal.nbEvents=len(PES)
    nbSubPop=len(PES[-1].densities)
    statVal.nbSubPop=nbSubPop
    statVal.meanN=np.mean(PES[-1].densities)
    statVal.varN=np.var(PES[-1].densities)
    statVal.meanXPop=np.mean(PES[-1].traits)
    statVal.varXPop=np.var(PES[-1].traits)
    statVal.meanLocPop=np.mean(PES[-1].locations)
    statVal.varLocPop=np.var(PES[-1].locations)
    
    meanTraitInd=0.0
    meanLocInd=0.0
    totalAbundance=0.0
    sackinIS = 0.0
    
    for i in range(nbSubPop):
        meanTraitInd+=(PES[-1].densities[i])*(PES[-1].traits[i])
        meanLocInd += (PES[-1].densities[i])*(PES[-1].locations[i])
        totalAbundance+=PES[-1].densities[i]
        sackinIS += PES[-1].popComposition[i].distRoot
      
    meanTraitInd/=totalAbundance
    
    statVal.meanXInd = meanTraitInd
    statVal.sackinIS = sackinIS
      
    varTraitInd=[]
    for subPop in range(nbSubPop):
        varTraitInd.append([((PES[-1].densities[subPop])*((abs((PES[-1].traits[subPop])-meanTraitInd))**2))])
    varTraitInd=np.mean(varTraitInd)/totalAbundance
    statVal.varXInd = varTraitInd
    
    meanLocInd/=totalAbundance    
    statVal.meanLocInd=meanLocInd
    
    varLocInd=[]
    for i in range(nbSubPop):
        varLocInd.append([((PES[-1].densities[i])*((abs((PES[-1].locations[i])-meanLocInd))**2))])
    varLocInd=np.mean(varLocInd)/totalAbundance
    statVal.varLocInd = varLocInd



        
    
    #---- if more than one sub-population and more than one trait                       
    #            measure between traits statistics for sub-populations x0 vs. x1
    listX = list(set(PES[-1].traits))
    if (len(listX) > 1):
        print("len traitsSampled > 1")       
        #------------------------------------------------------------------------------------
        #---- Difference for sub-populations with trait X0 -X1: Da, (delta mu)2, Ds, and Fst
        #------------------------------------------------------------------------------------
        if (len(listX) > 2):
            print("error!!! len(set(traitsSampled) > 2.", listX)
        
        nbX0 = 0
        nbX1 = 0
        locX0 = []
        locX1 = []
      
        for subPop in range(nbSubPop):
            xi = PES[-1].traits[subPop]
            if xi == listX[0] :
                nbX0 += 1
                locX0.extend([PES[-1].locations[subPop]])
            elif xi == listX[1] :
                nbX1 += 1                    
                locX1.extend([PES[-1].locations[subPop]])
            else:
                print("error x not in list",xi)

        varLocIntraX = (nbX0/float(nbX0 + nbX1)) * np.var(locX0) + (nbX1/float(nbX0 + nbX1)) * np.var(locX1)
        varLocInterX = (nbX0/float(nbX0 + nbX1)) * (np.mean(locX0)- np.mean(PES[-1].locations))**2 + (nbX1/float(nbX0 + nbX1)) * (np.mean(locX1) - np.mean(PES[-1].locations))**2

        statVal.varLocIntraX = varLocIntraX
        statVal.varLocInterX = varLocInterX
      
    return statVal


"""
            Descriptive statistics on the neutral locus
            
                    number of alleles (gives an idea of the population size)
                    variance of the alleles
                    M index (gives an idea of bottleneck occurrences)
                    genetic diversity
"""

import numpy as np
import copy
import math
# from scipy.cluster.hierarchy import weighted
# import time


def popMicrosatStatistics(sampledTrees, listXtsim, listNeutrals):
    """
        Calculate statistics on the neutral markers of the sampled individuals
            Get the Fst, the (delta mu)2, the Da and the Ds
    """
    #-------------------------------------------------------------------------------------
    #----       Determine the frequency of each allele in each sub-populations        ----
    #-------------------------------------------------------------------------------------
 
    #---- Empty structure : for each locus, size = number of alleles.
    #            It will be used for each sub-population, and filled with the frequency of each allele
    allelesID=[]
    allelesNb=[]
    emptyFrequences=[]
    for locusI in listNeutrals:
        allelesID.append(list(set(locusI)))
        allelesNb.append(len(allelesID[-1]))
        emptyFrequences.append([0.0]*allelesNb[-1])
        
   
    #---- Determine the number of individuals bearing each allele
    listX=[]
    nX=[]
    ntot = 0.0
    popXi=[]
    nbSampledX=[]
    nbNeutral=len(listNeutrals)
    
    for ind in sampledTrees:
        xi = ind.subPopulations[0].xEnv
        if not(xi in listX):
            listX.append(xi)
            nbSampledX.append(0.0)
            shape=copy.deepcopy(emptyFrequences)
            popXi.append(shape)
            nX.append(ind.subPopulations[0].densityEnv)
            ntot+=ind.subPopulations[0].densityEnv
    
    listX.sort()
    

    for ind in sampledTrees:
        xi = ind.subPopulations[0].xEnv
        neutrals = ind.NeutralMarkers[0:(nbNeutral-1)]
        
        idX = listX.index(xi)
        nbSampledX[idX]+=1
        for locus in range(len(neutrals)):
            allele=neutrals[locus]
            idA = allelesID[locus].index(allele)
            popXi[idX][locus][idA]+=1
            
    
    
    #---- Determine the frequence of each allele per population
    for idX in range(len(popXi)):
        for locus in range(len(popXi[idX])):
            popXi[idX][locus]=[i/float(nbSampledX[idX]) for i in popXi[idX][locus]]


    #-------------------------------------------------------------------------------------
    #----          Measure the distance between each pair of sub-population           ----
    #-------------------------------------------------------------------------------------    
    
    #---- If there is more than one sub-population => measure, otherwise NA.
    neiDa=np.nan
    deltaMu=np.nan
    neiDs=np.nan
    fst=np.nan
    weightedDa=np.nan
    weightedDeltaMu=np.nan
    weightedDs=np.nan
    weightedFst=np.nan
    
    
    if(len(popXi)>1):
        
        #---- Normalization of the number of repetitions (all positives)
        minAlleles = 0.0
        for locus in allelesID:
            minAlleles=min(minAlleles, min(locus))
        minAlleles=abs(minAlleles)+1
        
        allelesNormalized=[]
        for locus in allelesID:
            allelesNormalized.append([allele + minAlleles for allele in locus])
        
        nbLocus=len(allelesID)
        

        
        #---- For each pair of sub-populations, measure Da, (delta mu)2, Ds, and Fst
        neiDa=[]
        deltaMu=[]
        neiDs=[]
        fst=[]
        weightedDa=[]
        weightedDeltaMu=[]
        weightedDs=[]
        weightedFst=[]
        
        
        for idX0 in range(len(popXi)):
            for idX1 in range((idX0+1),len(popXi)):

                sumXX=0.0        
                sumYY=0.0
                sumXY=0.0
                
                neiDa01=0.0
                deltaMu01=0.0
                
                for idLocus in range(nbLocus):
            
                    muX=0.0
                    muY=0.0
                    
                    for idA in range(allelesNb[idLocus]):                
                        neiDa01+=math.sqrt(popXi[idX0][idLocus][idA] * popXi[idX1][idLocus][idA])
                
                        muX += allelesNormalized[idLocus][idA] * popXi[idX0][idLocus][idA]
                        muY += allelesNormalized[idLocus][idA] * popXi[idX1][idLocus][idA] 
                        
                        sumXX += popXi[idX0][idLocus][idA] * popXi[idX0][idLocus][idA]
                        sumYY += popXi[idX1][idLocus][idA] * popXi[idX1][idLocus][idA]
                        sumXY += popXi[idX0][idLocus][idA] * popXi[idX1][idLocus][idA]
                    
                    deltaMu01 += (muX-muY) * (muX-muY)
                    
                neiDa01/=float(nbLocus)
                neiDa01=1-neiDa01
                neiDa.append(neiDa01)
                
                weightedDa.append( (nX[idX0] * nX[idX1] * neiDa01)/float(ntot))

                deltaMu01/=float(nbLocus)
                deltaMu.append(deltaMu01)
                
                weightedDeltaMu.append((nX[idX0] * nX[idX1] * deltaMu01)/float(ntot))
                
                
                sumXX/=float(nbLocus)
                sumYY/=float(nbLocus)
                sumXY/=float(nbLocus)
                
                
                #---- If there is no shared alleles between population, sumXY=0 => Ds = ln(0) => NA
                try:
                    neiDs.append( math.log(sumXY/(math.sqrt(sumXX*sumYY))) )
                    weightedDs.append((nX[idX0] * nX[idX1] * (math.log(sumXY/(math.sqrt(sumXX*sumYY))))/float(ntot)))
                except:
                    if sumXY == 0:
                        #---- missing value (will not affect the mean => biased because doesn't reflect the population at all)
                        neiDs.append(np.nan)
                        weightedDs.append(np.nan)
# # #                         #---- replace with a small sumXY (as if we missed some similar individuals during the sampling)
# # #                         neiDs.append( math.log(0.00001/(math.sqrt(sumXX*sumYY))) )
# # #                         weightedDs.append( math.log(0.00001/(math.sqrt(sumXX*sumYY))) )
                    else:
                        print("error neiDs")
   
                #---- If two populations have the exact same neutral composition sumXX = sumYY = sumXY = 1
                #        fst = 0/0 => 0
                try:
                    fst.append( (((sumXX + sumYY)/2.0)-sumXY)/(1-sumXY) )
                    weightedFst.append((nX[idX0] * nX[idX1] *  ((((sumXX + sumYY)/2.0)-sumXY)/(1-sumXY)))/float(ntot) )
                except:
                    print("sums = 0")
                    if (sumXX == 1.0) & (sumYY == 1.0) &  (sumXY == 1.0):
                        fst.append(0.0)
                        weightedFst.append(0.0)
                    else:
                        print("error fst")
                
#     print(neiDa, deltaMu, neiDs,fst)

    return neiDa, deltaMu, neiDs, fst, weightedDa, weightedDeltaMu, weightedDs, weightedFst
    
    
        
    
        

def oneMicrosatStatistics(listAlleles):
    """
        Calculate basic statistics on each neutral marker of the sampled individuals

        For a multisatellite locus, get the allele number, the variance of this allele for the sample, the M index and the gene diversity. 
        
        Allele number: measure of the allelic diversity => useful to infer population size through time.
            => drift leads to the loss of alleles in small populations        
        
        M index: detection of reductions in population size (their intensity and duration)
            M index = nb alleles / range in allele size => the average percentage of intermediate allelic states that are occupied
            => The lower the M index, the more the population has lost possible alleles
                (in huge population, alleles should exist throughout the range size)
        
        Use of allele number and M index:
            low allele diversity and low M-index: recent reduction of size 
            low allele diversity but high M-index: small population for a long time
            
        Gene Diversity: expected difference between each couple of individuals in the population
            For each couple of two individuals in the population, sum of the difference of motif repeat
            
        Unbiased Gene Diversity: average difference between two individuals in the population
            Average difference of motif repeats between two individuals randomly drawn in the population
            
        Allele variance: 
    """
    #---- number of sampled individuals
    nbInd=float(len(listAlleles))
    
    #---- lists the different alleles of the sample (list of unique elements)
    allelesID=list(set(listAlleles))
    
    #---- number of different alleles in the sample
    allelesNb=len(allelesID)
    
    #---- Frequency of each allele
    freq=[0]*allelesNb
    for i in range(allelesNb):
        freq[i]=(listAlleles.count(allelesID[i]))/nbInd
    
    #---- Gene diversity
    #        sum of : dissimilarity coefficient * frequencies
    #            dissimilarity coefficient (difference in their number of motif repeats)
    #            cumulative difference between individuals
    geneDiv=0.0
    for i in range(allelesNb):
        for j in range(allelesNb):
            geneDiv += abs(allelesID[i] - allelesID[j]) * freq[i] * freq[j]
    
    #---- Unbiased gene diversity: average on the sampled individuals.
    unbiasedGeneDiv = (nbInd/(nbInd-1))*geneDiv
    
    #---- variance of the sampled individuals
    varAl=np.var(listAlleles)
    
    #---- M index: nb alleles / range in allele size
    r=np.max(allelesID)-np.min(allelesID)+1
    mI= allelesNb/r
    
    
    return(allelesNb,unbiasedGeneDiv, geneDiv, varAl,mI)



def sampleStatistics(sampledInd):
    """
        Calculate statistics on the sampled individuals
            nbSubPopSampled: number of sampled sub-populations
            relativeAbundance: relative abundance variance between sampled sub-populations
            meanTraitSampledPop: mean trait of sampled sub-populations
            varTraitSampledPop: trait variance between sampled sub-populations
            meanTraitIndSampled: mean trait of sampled individuals (vary with density)
            varTraitIndSampled: trait variance between sampled individuals (vary with density)
    """
    
    nbSampledInd=0
    nbSubPopSampled = 0
    traitsSampled=[]
    
    relativeAbundance=[]
    
    meanTraitIndSampled=0.0
    
    for sampleSubPop in sampledInd:
        
        nbSampledIndSubPop = len(sampleSubPop)
        nbSampledInd += nbSampledIndSubPop
        
        if nbSampledIndSubPop > 0:
            
            nbSubPopSampled += 1
            
            relativeAbundance.append(nbSampledIndSubPop)
                        
            xi = sampleSubPop[0].subPopulations[0].xEnv
            traitsSampled.extend([xi])            
            
            meanTraitIndSampled += (xi) * nbSampledIndSubPop
   
    relativeAbundance=[nbInd/float(nbSampledInd) for nbInd in relativeAbundance]
    varRelativeAbundance=np.var(relativeAbundance)
  
    
    meanTraitIndSampled /=nbSampledInd
    meanTraitSampledPop = np.mean(traitsSampled)
    varTraitSampledPop = np.var(traitsSampled)
    
    varTraitIndSampled=[]
    for i in range(nbSubPopSampled):
        varTraitIndSampled.append([((relativeAbundance[i])*((abs((traitsSampled[i])-meanTraitSampledPop))**2))])
    varTraitIndSampled=np.mean(varTraitIndSampled)
    
    return(nbSubPopSampled, varRelativeAbundance, meanTraitSampledPop, varTraitSampledPop, meanTraitIndSampled, varTraitIndSampled)


def pesStatistics(PES):
    """
        Calculate statistics on the PES.
            nbEvents: number of mutation events along the PES
            nbSubPop: number of coexisting sub-populations at tsim
            meanAbundance: mean abundance of the coexisting sub-populations at tsim
            varAbundance: variance of the abundance of the coexisting sub-populations at tsim
            meanTraitPop: mean trait x of the sub-populations
            varTraitPop: trait variance between sub-populations
            meanTraitInd: mean trait x of the individuals in all sub-populations (depends on densities)
            varTraitInd: variance between the traits of individuals in all sub-populations (depends on densities)            
    """
    nbEvents=len(PES)
    nbSubPop=len(PES[-1].densities)
    meanAbundance=np.mean(PES[-1].densities)
    varAbundance=np.var(PES[-1].densities)
    meanTraitPop=np.mean(PES[-1].traits)
    varTraitPop=np.var(PES[-1].traits)
      
    meanTraitInd=0.0
    totalAbundance=0.0
    sackinIS = 0.0
    
    for i in range(nbSubPop):
        meanTraitInd+=(PES[-1].densities[i])*(PES[-1].traits[i])
        totalAbundance+=PES[-1].densities[i]
        sackinIS += PES[-1].popComposition[i].distRoot
        
    meanTraitInd/=totalAbundance
      
    varTraitInd=[]
    for i in range(nbSubPop):
        varTraitInd.append([((PES[-1].densities[i])*((abs((PES[-1].traits[i])-meanTraitInd))**2))])
    varTraitInd=np.mean(varTraitInd)/totalAbundance
    
    return nbEvents,nbSubPop,meanAbundance,varAbundance,meanTraitPop,varTraitPop,meanTraitInd,varTraitInd,sackinIS

"""
            Give values to the parameters: random values or fixed ones
"""


import numpy as np
import random as rd




def meanfield(x,mean):
    return(mean)
 
def curryMeanfield(mean):
    """
        Nested function (independent of the trait xi).  Will be used with mean = d and mean = eta.
        Gives the values of death rate (dfun(xi) = d) and competition coefficient (etafun(xi) = eta)
    """
    return lambda x:meanfield(x,mean)
 
def gaussianKernel(x,sig):
    return(np.exp(-(x/sig)**2)/2)
 
def curryGaussian(sig):
    """
        Nested function. Will be used with sig = b and sig = C.
        Calculates the values of birth rate (bfun(xi)) and competition (Cfun(xi-xj)) depending of the trait xi
    """
    return lambda x: gaussianKernel(x,sig)



def randomParameters():
    """ Draw random parameters """
#     p=1/rd.uniform(100,1000)
#     minM=-2.
#     maxM=2.
#     sigB=np.exp(rd.uniform(-1,1))
#     sigC=np.exp(rd.uniform(-1,1))
#     sigM=np.exp(rd.uniform(-2,-1))
#     etaC=rd.uniform(0.01,0.1)
#     dC=0.
#     tsim=rd.expovariate(1/6e2)
#     theta=1/(rd.uniform(0.5,5))
    
    p=rd.uniform(0.007,0.008)
    minM=-2.
    maxM=2.
    sigB=rd.uniform(0.01,3)
    sigC=rd.uniform(0.01,1)
    sigM=rd.uniform(0.01,0.5)
    etaC=rd.uniform(0.01,0.1)
    dC=0.
    tsim=rd.expovariate(1/6e2)
    theta=rd.uniform(0.1,1)
    
    #-------------- Define functions for parameters that vary with xi (suffix fun)
    bfun=curryGaussian(sigB)        #---- Returns b(xi) birth rate depending on trait value
    dfun=curryMeanfield(dC)         #---- Returns d(xi)=d death rate
    etafun=curryMeanfield(etaC)     #---- Returns eta(xi)=eta competition coefficient
    Cfun=curryGaussian(sigC)        #---- Returns C(xi) competition depending on trait values
    
    return(p,minM,maxM,sigB,sigC,sigM,etaC,dC,tsim,theta,bfun,dfun,etafun,Cfun)



def fixedParameters():
    """ Define fixed parameters """
    # many traits 
#     p=0.003
#     minM=-2.
#     maxM=2.
#     sigB=1.2
#     sigC=0.4
#     sigM=0.35
#     etaC=0.02
#     dC=0.
#     tsim=1500
#     theta=0.01
 
#     p=0.0011
#     minM=-2.
#     maxM=2.
#     sigB=2.1378
#     sigC=0.68
#     sigM=0.3531
#     etaC=0.0483
#     dC=0.
#     tsim=859.6191
#     theta=0.4479

    
#     p=0.0071
#     minM=-2.
#     maxM=2.
#     sigB=1.7725
#     sigC=0.3866 
#     sigM=0.1372
#     etaC=0.0306
#     dC=0.
#     tsim=335.2116
#     theta=0.6815


    p=0.0071
    minM=-2.
    maxM=2.
    sigB=1.7725
    sigC=0.3866 
    sigM=0.1372
    etaC=0.0306
    dC=0.
    tsim=335.2116
    theta=0.6815
    
    #-------------- Define functions for parameters that vary with xi (suffix fun)
    bfun=curryGaussian(sigB)        #---- Returns b(xi) birth rate depending on trait value
    dfun=curryMeanfield(dC)         #---- Returns d(xi)=d death rate
    etafun=curryMeanfield(etaC)     #---- Returns eta(xi)=eta competition coefficient
    Cfun=curryGaussian(sigC)        #---- Returns C(xi) competition depending on trait values
    
    return(p,minM,maxM,sigB,sigC,sigM,etaC,dC,tsim,theta,bfun,dfun,etafun,Cfun)

"""
            I Polymorphic evolution Sequence: Simulation of trait mutations (forward time):
            
                    Forward time: from a single sub-population at t0 to n sub-population at tsim
                    Until tsim => successive mutations in the population
                                Determine the sub-population in which the mutant emerges
                                Determine the population composition after its emergence (densities) 
                    Returns the characteristics of the sub-populations (trait/density) between steps of the PES.
"""


import numpy as np
import time

import lotkaVolterra as lv
import generateMutation as mut

class Population():
    """
        class Population: characteristics of the population at a given time
            tO : time of the initial event leading to this population structure
            tf: time of the next evolutionary event (will modify the structure)
            popComposition: list of all the sub-populations existing at this time
            traits: trait of all the sub-populations
            densities: densities of all the sub-populations
            idNewMutant: adress of the sub-population that appeared at t0
            listX: all the traits that existed along the PES
    """   
    def __init__(self,ti,subPopulations,x,n,idMut,previousListX=[]):
        self.t0=ti
        self.popComposition=subPopulations
        self.traits = x
        self.densities = n
        self.newSubPop = idMut
        self.listX = np.append(previousListX,idMut.xi)





class SubPop():
    """
        class SubPop: characteristics of sub-population
            timeEmergence: time of emergence of the new trait
            timeExtinction: time of the extinction of the population
            x: trait of the sub-population
            idparent: adress of the sub-population that created the mutant
            idchildren: address of the mutants produced from this trait
            distRoot: distance from the root
    """
    def __init__(self, temerg, xi, origin):
        self.timeEmergence = temerg
        self.timeExtinction = None
        self.xi = xi
        self.origin=origin
        self.children=[]
        try:
            self.distRoot = origin.distRoot + 1
        except:
            self.distRoot = 0

        



def PES(x0,n0,bfun,dfun,etafun,Cfun,p,tsim,sigM,minM,maxM):
    """ PES takes an initial population (trait x0, density n0) and simulates the evolution of the trait.
    
        At each step:
            Successful emergence of a new mutant => substitution or coexistence with other sub-populations
            Add a cell to PES with the info on each coexisting sub-population (time, [n0,...,nk],[x0,...xk], [parentX0,...,parentXk])
            parentXi = [emergence time of xi, trait of the sub-population in which xi emerged, identity of the sub-population in which xi emerged]
        PES returns a table with in each cell the characteristics of the population between jumps of the trait distribution. (length = number of jumps)
    """ 
    ###---- Initialization of the tree: at time t=0 -> 1 pop (with trait x0)
    t=0
    subPopulations = [(SubPop(t,x0,None))]
#     parent=np.array([[t,0,x0,0]])
    b=np.array([bfun(x0)])
    d=np.array([dfun(x0)])
    eta=np.array([etafun(x0)])
    x=np.array([x0])
    n=np.array([n0])
    
    PES=[Population(t,subPopulations,x,n,subPopulations[0])]
    
    clock0 = time.clock()
    timeExceeded = False
    
    while (t<tsim) & (not(timeExceeded)):
        """---- Ia : Determine the time step for a mutant to emerge
           ---- Ib : Determine the trait value of the mutant"""
        tstep,xmut,ip = mut.stepMutation(x,n,bfun,dfun,etafun,Cfun,p,tsim-t,sigM,minM,maxM)
        
        idparent = subPopulations[ip]
        if t+tstep<tsim:
            #---- Keep the time of emergence, the mutant trait and the parent identity (idparent): will be appended to PES.
            t=t+tstep
            newSubPop = SubPop(t, xmut, idparent)
            subPopulations = np.append(subPopulations,[newSubPop])
            """---- Ic : Determine the densities of each population (invasion/extinction/coexistence of the traits)"""
            n,x,b,d,eta,subPopulations=lv.solverF(n,b,d,eta,Cfun,x,xmut,bfun(xmut),dfun(xmut),etafun(xmut),t,subPopulations)
            
            #---- Add to PES the populations characteristics at time t
            PES.append(Population(t,subPopulations,x,n,newSubPop,PES[-1].listX))
            
            timeExceeded = (float(time.clock() - clock0) > 20)
        else:
            t=tsim
            for subPopulation in PES[-1].popComposition:
                subPopulation.timeExtinction = tsim
            
    return(PES,timeExceeded)





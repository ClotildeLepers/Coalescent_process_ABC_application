"""
            Plot of the PES and of the coalescence tree.
"""


import numpy as np
import matplotlib.pyplot as plt
import time

def defineColorsX(listX):
    """
        Attribute a color to each trait value
    """
#     cmap = plt.get_cmap('gist_rainbow')
#     colors = [cmap(i) for i in np.linspace(0, 1, len(listX))]
#     if len(listX) < 12:
#         print("paired")
#         cmap = plt.get_cmap('Paired')
#     elif len(listX)<20:
#         print("set1+paired")        
#         cmap = list(plt.get_cmap('Set1'),plt.get_cmap('Paired'))

#     if len(listX) < 8:
#         cmap = plt.get_cmap('Dark2')
#     el
    if len(listX) < 9:
        cmap = plt.get_cmap('Set1')
    else:
        cmap = plt.get_cmap('gist_rainbow')
    colors = [cmap(i) for i in np.linspace(0, 1, len(listX))]
    
    return colors



def plotPES(PES,tsim,colors,listX):
    
    plt.figure('PES')
    
    subPopulations=[]
    for pop in PES:
        subPopulations.extend(pop.popComposition)
    
    subPopulations=set(subPopulations)

    for subPopulation in subPopulations:
        try:
            idColorV,=(np.where(listX==subPopulation.origin.xi))
            plt.plot([subPopulation.timeEmergence,subPopulation.timeEmergence],[subPopulation.xi,subPopulation.origin.xi],color=colors[idColorV[0]],linestyle='--', linewidth=1.5)
        except:
            print("origin:",subPopulation.origin)
        
        idColor,=(np.where(listX==subPopulation.xi))
        plt.plot([subPopulation.timeEmergence,subPopulation.timeExtinction],[subPopulation.xi,subPopulation.xi],color=colors[idColor[0]], linewidth=1.5)
        
    #---- Add margins
    axes = plt.gca()
    axes.set_ylim((axes.get_ybound()[0] - 0.1), (axes.get_ybound()[1] + 0.1) )  
    
    plt.show()





def plotGeneralRecur(tree,y,k,listX, colors):
    """
        Plots a coalescent tree
    """
    
    plt.figure('coalescent')
           
    #---- Horizontal line: last event to previous one etc
    for env in tree.subPopulations:
        idColor,=(np.where(listX==env.xEnv))
        print("ind ",tree,"x ind",env.xEnv,"y ind",y,"t0",env.tOEnv,"tf",env.tfEnv)
        plt.plot([env.tOEnv,env.tfEnv],[y, y], color=colors[idColor[0]], linewidth=1.0)
        
    if tree.left!=None and tree.right!=None:
        #---- Vertical line to join the left and right children (time = emergence of children; color = last x of the individual)
        envI=tree.subPopulations[0]
        idColor,=(np.where(listX==envI.xEnv))
        plt.plot([envI.tfEnv,envI.tfEnv],[y,y+1.0/(2**k)], color=colors[idColor[0]], linewidth=1.0)
        
        #---- Draw the left and right children
        plotGeneralRecur(tree.left,y,k+1,listX, colors)
        plotGeneralRecur(tree.right,y+1.0/(2**k),k+1,listX, colors)




def plotGeneral(listcoal,tfin,listX, colors):
    """
        Plots several coalescent trees
    """
    
    for i in range(len(listcoal)):
        plt.figure('coalescent')
        plotGeneralRecur(listcoal[i],i,1,listX,colors)
        
    #---- Add margins
    axes = plt.gca()
    axes.set_ylim(-0.1, (axes.get_ybound()[1] + 0.1) )       

    plt.show()
"""
    simulationsLauncher.py 
        Set parameters
        Launch PES
        Launch individual coalescence
        Launch neutral mutations
        Measure and save statistics
"""

import sys
import numpy as np
import random as rd
import csv
# import warnings
import time

import getParameters as param
import generatePES as gpes
import generateMutation as mut
import lotkaVolterra as lv
import binaryTree as bt
import coalescence as coal
import neutralMutations as nt
import descriptiveStats as st
import plots

sys.setrecursionlimit(10000) 

    

def samplefromPop(n):
    """
        Randomly selects an individual in the population
          and send back its category (population id)
    """
    #---- Sum up the densities of each sub-population
    popDensity = np.sum(n)
    compt=0
    #---- Randomly draw an individual
    z=rd.uniform(0,popDensity)
    i=-1
    #---- Determine the sub-population identity of the drawn individual
    while compt<z:
        compt=compt+n[i]
        i=i+1
    return(i)
 
"""--------------------------------------------------------------------
   --------------           Open saving files            --------------
   --------------------------------------------------------------------"""


nbNeutralLocus=100
neutralList=range(int(nbNeutralLocus/10),nbNeutralLocus+1,10)


#---- Open a file to save parameters and statistics of simulations
data_100neutral = open('simulations_100neutral_A-D.csv','ab',0) # ab = append in binary file ; 0 => no buffering
data_90neutral = open('simulations_90neutral_A-D.csv','ab',0) # ab = append in binary file ; 0 => no buffering
data_80neutral = open('simulations_80neutral_A-D.csv','ab',0) # ab = append in binary file ; 0 => no buffering
data_70neutral = open('simulations_70neutral_A-D.csv','ab',0) # ab = append in binary file ; 0 => no buffering
data_60neutral = open('simulations_60neutral_A-D.csv','ab',0) # ab = append in binary file ; 0 => no buffering
data_50neutral = open('simulations_50neutral_A-D.csv','ab',0) # ab = append in binary file ; 0 => no buffering
data_40neutral = open('simulations_40neutral_A-D.csv','ab',0) # ab = append in binary file ; 0 => no buffering
data_30neutral = open('simulations_30neutral_A-D.csv','ab',0) # ab = append in binary file ; 0 => no buffering
data_20neutral = open('simulations_20neutral_A-D.csv','ab',0) # ab = append in binary file ; 0 => no buffering
data_10neutral = open('simulations_10neutral_A-D.csv','ab',0) # ab = append in binary file ; 0 => no buffering

data_10neutralWriter=csv.writer(data_10neutral)
data_20neutralWriter=csv.writer(data_20neutral)
data_30neutralWriter=csv.writer(data_30neutral)
data_40neutralWriter=csv.writer(data_40neutral)
data_50neutralWriter=csv.writer(data_50neutral)
data_60neutralWriter=csv.writer(data_60neutral)
data_70neutralWriter=csv.writer(data_70neutral)
data_80neutralWriter=csv.writer(data_80neutral)
data_90neutralWriter=csv.writer(data_90neutral)
data_100neutralWriter=csv.writer(data_100neutral)

stoppedSimul = open('stoppedSimul_A-D.csv','ab',0) # ab = append in binary file ; 0 => no buffering
stoppedSimulsWriter=csv.writer(stoppedSimul)

# # # #---- If only part of the statistics are saved:
# data_selectedStat = open('selectStat.csv','ab',0) # ab = append in binary file

"""--------------------------------------------------------------------
   --------------              Simulations               --------------
   --------------------------------------------------------------------"""
# # # #---- Define parameters => several simulations with the same values
p,minM,maxM,sigB,sigC,sigM,etaC,dC,tsim,theta,bfun,dfun,etafun,Cfun = param.fixedParameters()
# # # p,minM,maxM,sigB,sigC,sigM,etaC,dC,tsim,theta,bfun,dfun,etafun,Cfun = param.randomParameters()



for simul in range(2):

    clockSimul=time.clock()
 

    #---- Define random parameters: different values at each simulation
    #p,minM,maxM,sigB,sigC,sigM,etaC,dC,tsim,theta,bfun,dfun,etafun,Cfun = param.randomParameters()
    print("nouvelle simul, p", p,"sigB",sigB,"sigC",sigC,"sigM",sigM,"etaC",etaC,"tsim",tsim,"theta",theta)


    """----------------------------------------------------------------
       --------------  Creation of the first population  --------------
       ----------------------------------------------------------------"""
    n0=0
    while n0==0:
# # #         #---- Draw the trait randomly in a normal distribution
# # #         x0=mut.gaussianMutation(0,sig=sigM)

# # #         #---- Draw the trait randomly in a truncated normal distribution
# # #         x0=mut.truncatedGaussianMutation(0,sig=sigM,a=minM,b=maxM)

        x0 = 0 

        #---- Calculates the population density at equilibrium
        n0=lv.steadyPop(bfun(x0),dfun(x0),etafun(x0),Cfun(0))

    
    """----------------------------------------------------------------
       ----------------------------------------------------------------
       ----------------------------------------------------------------
       -----           I Polymorphic Evolution Sequence:          -----
       -----     Simulation of trait mutations (forward time)     -----
       ----------------------------------------------------------------
       ----------------------------------------------------------------
       ----------------------------------------------------------------"""
    PES,timeExcess = gpes.PES(x0,n0,bfun,dfun,etafun,Cfun,p,tsim,sigM,minM,maxM)
    if timeExcess:
        print("stop the simulation at PES. Time exceeded.")
        stoppedSimulsWriter.writerow([round(p,4),round(sigM,4),round(sigB,4),round(etaC,4),round(sigC,4),round(tsim,4),round(theta,4),"PEStimeExcess"])
        # print("densities at stopping time:", PES[-1].densities)
        continue
    
    #---- Save all trait values along the PES
    listX=PES[-1].listX
    
    if (len(PES[-1].densities)<2):
        print("stop the simulation at PES. 1 population.")
        stoppedSimulsWriter.writerow([round(p,4),round(sigM,4),round(sigB,4),round(etaC,4),round(sigC,4),round(tsim,4),round(theta,4),"1pop"])
        # print("densities at stopping time:", PES[-1].densities)
        continue
    
    """ Statistics on the PES (not available on real data)
            number of mutation events
            number of sub-populations
            mean abundance of sub-populations
            abundance variance between sub-populations
            mean trait of sub-populations
            trait variance between sub-populations
            mean trait of individuals (vary with density)
            trait variance between individuals (vary with density)
                                                                       """
    nbEvents,nbSubPop,meanN,varN,meanXpop,varXpop,meanXind,varXind, sackinIS = st.pesStatistics(PES)
#     print(nbEvents, nbSubPop, meanN,varN,meanXpop,varXpop,meanXind,varXind)


    """          Draw the PES (one color per trait value)              """
#     colors = plots.defineColorsX(listX)
# #     print(PES)
#     plots.plotPES(PES, tsim, colors, listX)
    
 
    """----------------------------------------------------------------
       ----------------------------------------------------------------
       ----------------------------------------------------------------
       -----        Sampling of individuals at time tsim          -----
       -----   => on the leaves of the tree (last generation)     -----
       ----------------------------------------------------------------
       ----------------------------------------------------------------
       ----------------------------------------------------------------""" 
    sampleSize=1000
  
    #---- sample is a table with a cell for each sub-population
    #        sampled individuals are added in their sub-population cell
    ntsim=PES[-1].densities
    xtsim=PES[-1].traits
    subPoptsim = PES[-1].popComposition
      
    sample=[]
    for i in range(len(ntsim)):
        sample.append([])
  
    for i in range(sampleSize):
        j=samplefromPop(ntsim)
        sample[j].append(bt.BinaryTree(tsim,subPoptsim[j],ntsim[j]))
    
    while [] in sample:
        sample.remove([]) 
    
 
    """ Statistics on the sampled individuals
            number of sampled sub-populations
            variance of the relative abundance of sampled sub-populations
            mean trait of sampled sub-populations
            trait variance of sampled sub-populations
            mean trait of sampled individuals (vary with density)
            trait variance of sampled individuals (vary with density)
                                                                       """
 
    nbSubPopSampled, varNrelSample, meanXpopSample, varXpopSample, meanXindSample, varXindSample = st.sampleStatistics(sample)
#     print(nbSubPopSampled, varNrelSample, meanXpopSample, varXpopSample, meanXindSample, varXindSample)
     
    """----------------------------------------------------------------
       ----------------------------------------------------------------
       ----------------------------------------------------------------
       ----- II Phylogeny of individuals conditionally to the PES -----
       -----           Coalescence of sampled individuals         -----
       ----------------------------------------------------------------
       ----------------------------------------------------------------
       ----------------------------------------------------------------"""
    #---- listCoalTrees lists the common ancestors (not coalesced at t0)
    #        PES and sample are modified in the function.
    #        To preserve PES and sample => send copies to coalStep 
    #                         => copy=list(...) but time consuming!
    clock0 = time.clock()
    listCoalTrees,timeExcess,nbCherries,sumCoalExternalBranchLength = coal.coalStep(PES,tsim,sample,bfun,clock0,PES[-1].popComposition,tsim,timeExceeded=False)
    #---- Flattens the matrix (all individuals are from sub-pop 0)
    listCoalTrees = listCoalTrees[0]

    if (timeExcess):
        print("stop the simulation at coalescence, time exceeded")
        stoppedSimulsWriter.writerow([round(p,4),round(sigM,4),round(sigB,4),round(etaC,4),round(sigC,4),round(tsim,4),round(theta,4),"coaltimeExcess"])
        print("nb of PES events:", nbEvents)
        continue
    
    #---- save time before the most recent common ancestor (if no common ancestor => tsim)
    
    if len(listCoalTrees) > 1:
        tMRCA = tsim
    else:
        tMRCA = tsim - listCoalTrees[0].tSampling

    

    """ Draw the coalescent tree. Colors depend on trait value (as PES)"""
#     colors = plots.defineColorsX(listX)
#     plots.plotGeneral(listCoalTrees, tsim,listX,colors)

    
    """----------------------------------------------------------------
       ----------------------------------------------------------------
       ----------------------------------------------------------------
       -----    III Neutral locus mutation along the phylogeny    -----
       -----   Microsatellite mutation (gain or loss of a motif)  -----
       ----------------------------------------------------------------
       ----------------------------------------------------------------
       ----------------------------------------------------------------"""
     
    #---- listNeutral: for each neutral microsatellite locus
    #     => alleles (number of motif repeat) that exist in the population
    #---- Modifies neutralMarker of sampledTrees.
    listNeutral,sampledTrees=nt.mutlistTree(listCoalTrees,theta,bfun,nbNeutralLocus)
#     print(listNeutral)
    
    """ Statistics on the neutral locus (i) basic statistics for each locus
            number of alleles
                => higher diversification in larger populations
            gene diversity
                => average distance between two individuals
            variance of the number of motif repeats
                => higher variance with long time to diverge
            M index
                => detection of bottlenecks
                                                                        """
    nbAlleles=[]
    unbiasedGeneDiversity=[]
    geneDiversity=[]
    varAlleles=[]
    mIndex=[]

    for i in range(len(listNeutral)):        
        nbAl,unbiasedGeneDiv,geneDiv,varAl,mI =st.oneMicrosatStatistics(listNeutral[i])
        nbAlleles.extend([nbAl])               
        unbiasedGeneDiversity.extend([unbiasedGeneDiv])        
        geneDiversity.extend([geneDiv]) 
        varAlleles.extend([varAl])
        mIndex.extend([mI])
    
    
    meanNbAllleles = []
    meanUnbiasedGeneDiversity = []
    meanGeneDiversity=[]
    meanVarAlleles=[]
    meanMIndex=[]
    listNeiDa=[]
    listDeltaMu=[]
    listNeiDs=[]
    listFst=[]
    listWeightedDa=[]
    listWeightedDeltaMu=[]
    listWeightedDs=[]
    listWeightedFst =[]

    for i in neutralList:
        meanNbAllleles.extend([np.mean(nbAlleles[0:(i-1)])])
        meanUnbiasedGeneDiversity.extend([np.mean(unbiasedGeneDiversity[0:(i-1)])])
        meanGeneDiversity.extend([np.mean(geneDiversity[0:(i-1)])])
        meanVarAlleles.extend([np.mean(varAlleles[0:(i-1)])])
        meanMIndex.extend([np.mean(mIndex[0:(i-1)])])
        
        """ Statistics on the neutral locus (ii) population diversification
            Da
            Ds
            (Delta mu)^2
            Fst
                                                                       """   
        neiDa, deltaMu, neiDs, fst, weightedDa, weightedDeltaMu, weightedDs, weightedFst = st.popMicrosatStatistics(sampledTrees,xtsim,listNeutral[0:(i-1)])
        listNeiDa.extend([neiDa])
        listDeltaMu.extend([deltaMu])
        listNeiDs.extend([neiDs])
        listFst.extend([fst])
        listWeightedDa.extend([weightedDa])
        listWeightedDeltaMu.extend([weightedDeltaMu])
        listWeightedDs.extend([weightedDs])
        listWeightedFst.extend([weightedFst])
   
    """----------------------------------------------------------------
       -----          VI Save the descriptive statistics         ------
       ----------------------------------------------------------------"""
       
    # parameters
    listParam = [round(p,4),round(sigM,4),round(sigB,4),\
                 round(etaC,4),round(sigC,4),round(tsim,4),round(theta,4)]
    # population statistics
    listPopStat = [round(nbSubPop,4),round(meanN,4),round(varN,4), \
                   round(meanXpop,4),round(varXpop,4),round(meanXind,4),round(varXind,4)]
    # sample statistics
    listSampleStat = [round(nbSubPopSampled,4), round(varNrelSample,4),\
                      round(meanXpopSample,4), round(varXpopSample,4), round(meanXindSample,4), round(varXindSample,4)]

    # tree (PES/coalescent) statistics
    listTreesStat = [round(nbEvents,4), round(sackinIS,4), round(sumCoalExternalBranchLength,4),\
                     round(nbCherries,4),round(tMRCA,4)]

    for i in range(len(neutralList)):
        listToSave = []
        # basic neutrals statistics
        listNeutralStat = [round(meanNbAllleles[i],4),round(meanUnbiasedGeneDiversity[i],4),round(meanGeneDiversity[i],4), \
                           round(meanVarAlleles[i],4),round(meanMIndex[i],4)]

        # population neutral statistics : depends on the number of populations!
        listPopNeutralStat=[]
        if nbSubPopSampled == 1:        
            listPopNeutralStat=[round(np.nan,4), round(np.nan,4),\
                                round(np.nan,4), round(np.nan,4),\
                                round(np.nan,4),round(np.nan,4),\
                                round(np.nan,4), round(np.nan,4),\
                                # population neutral weighted statistics
                                round(np.nan,4), round(np.nan,4),\
                                round(np.nan,4), round(np.nan,4),\
                                round(np.nan,4),round(np.nan,4),\
                                round(np.nan,4), round(np.nan,4)]
        elif nbSubPopSampled == 2:
            # population neutral statistics
            listPopNeutralStat=[round(np.nanmean(listNeiDa[i]),4), np.nan,\
                                round(np.nanmean(listNeiDs[i]),4), np.nan,\
                                round(np.nanmean(listDeltaMu[i]),4),np.nan,\
                                round(np.nanmean(listFst[i]),4), np.nan,\
                                # population neutral weighted statistics
                                round(np.nanmean(listWeightedDa[i]),4), np.nan,\
                                round(np.nanmean(listWeightedDs[i]),4), np.nan,\
                                round(np.nanmean(listWeightedDeltaMu[i]),4),np.nan,\
                                round(np.nanmean(listWeightedFst[i]),4), np.nan]
        else:
            # population neutral statistics
            listPopNeutralStat = [round(np.nanmean(listNeiDa[i]),4), round(np.nanvar(listNeiDa[i]),4),\
                                  round(np.nanmean(listNeiDs[i]),4), round(np.nanvar(listNeiDs[i]),4),\
                                  round(np.nanmean(listDeltaMu[i]),4),round(np.nanvar(listDeltaMu[i]),4),\
                                  round(np.nanmean(listFst[i]),4), round(np.nanvar(listFst[i]),4),\
                                  # population neutral weighted statistics
                                  round(np.nanmean(listWeightedDa[i]),4), round(np.nanvar(listWeightedDa[i]),4),\
                                  round(np.nanmean(listWeightedDs[i]),4), round(np.nanvar(listWeightedDs[i]),4),\
                                  round(np.nanmean(listWeightedDeltaMu[i]),4),round(np.nanvar(listWeightedDeltaMu[i]),4),\
                                  round(np.nanmean(listWeightedFst[i]),4), round(np.nanvar(listWeightedFst[i]),4)]
    
     
        listToSave.extend(listParam)
        listToSave.extend(listPopStat)
        listToSave.extend(listSampleStat)
        listToSave.extend(listNeutralStat) 
        listToSave.extend(listPopNeutralStat)     
        listToSave.extend(listTreesStat)
        if i == 0 :
            data_10neutralWriter.writerow(listToSave)
        elif i == 1 :
            data_20neutralWriter.writerow(listToSave)
        elif i == 2 :
            data_30neutralWriter.writerow(listToSave)
        elif i == 3 :
            data_40neutralWriter.writerow(listToSave)
        elif i == 4 :
            data_50neutralWriter.writerow(listToSave)
        elif i == 5 :
            data_60neutralWriter.writerow(listToSave)
        elif i == 6 :
            data_70neutralWriter.writerow(listToSave)
        elif i == 7 :
            data_80neutralWriter.writerow(listToSave)
        elif i == 8 :
            data_90neutralWriter.writerow(listToSave)
        elif i == 9 :
            data_100neutralWriter.writerow(listToSave)
     
    
   
#     datawriter=csv.writer(data_selectedStat)
#     datawriter.writerow([round(p,4),round(sigB,4),round(sigC,4),round(sigM,4),round(etaC,4),round(tsim,4),round(theta,4), \
#                              round(nbEvents,4), round(nbSubPop,4),round(meanN,4),round(varN,4), \
#                              round(meanXpop,4),round(varXpop,4),round(meanXind,4),round(varXind,4),\
#                              round(sackinIS,4),round(sumCoalExternalBranchLength,4),\
#                              round(nbCherries,4),round(tMRCA,4)])



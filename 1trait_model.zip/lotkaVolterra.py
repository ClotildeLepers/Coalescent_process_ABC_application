
"""
            Ic Determine the equilibrium densities of each sub-population:
            
                    ODE for each sub-populations (f)
                    Equilibrium density of an isolated population (steadyPop)
                    Equilibrium densities of sub-populations (solveFromData)
"""


import numpy as np
# import time
from scipy.integrate import ode
# # # import matplotlib.pyplot as plt


def f(t,n,b,d,eta,Cfun,x):
    """
        Returns a table of the sub-populations growth rates.
        
        Keyword arguments:
            t -- time            
            
            C -- Function of competition
            
            n -- sub-population densities
            b -- sub-population birth rates
            d -- sub-population death rates
            eta -- sub-population competition coefficients
            x -- sub-population trait values
    """
    nbSubPop=np.size(n)
    growthRates=np.zeros(nbSubPop)
    for i in range(nbSubPop):
        comp=0
        for j in range(nbSubPop):
            comp=comp+Cfun(x[i]-x[j])*n[j]
        growthRates[i]=((b[i]-d[i]-eta[i]*comp)*n[i])
    return growthRates



def steadyPop(bi,di,etai,C0):
    """
        Returns the equilibrium density of the isolated population i.
        
        -------------------------------------------------------
        Assuming dni/dt = ( bi - di - eta Sum(C(xi-xj)nj) ) ni
        One trait -- dni/dt = (bi - di - etai C(0) ni) ni
        => ni=0 or ni=((bi-di)/(etai*C(0)))
        -------------------------------------------------------
        
        Keyword arguments:
            CO -- competition within sub-population C(0)
            bi -- sub-population birth rate (1 value)
            di -- sub-population death rate (1 value)
            etai -- sub-population competition coefficient (1 value)
    """
    return((bi-di)/(etai*C0))



def newtonLV(n,b,d,eta,Cfun,x):
    """
        Newton method for Lotka-Volterra ODE.
        Returns the densities at equilibrium of sub-populations.
        
        Multivariate Newton method (used once the densities are already near the equilibrium):
            f'(nt)(nt+1 - nt) = -f(nt)
            Jacobian matrix (A = f'(nt)): partial derivative (Fi, ni) = (bi-di) - etai Sum(C(xi-xj)nj) - etai C(xi-xi) ni
                                          partial derivative (Fi, nj) = - etai C(xi-xj) ni
            b = -f(nt)                 
        Solves A (nt+1-nt) = b => obtain (nt+1 - nt).
    """
    nbSubPop=len(n)
    jacobianMatrix=np.zeros([nbSubPop,nbSubPop])
    for i in range(nbSubPop):
        for j in range(nbSubPop):
            jacobianMatrix[i,j]=jacobianMatrix[i,j]-eta[i]*Cfun(x[i]-x[j])*n[i]
            jacobianMatrix[i,i]=jacobianMatrix[i,i]-eta[i]*Cfun(x[i]-x[j])*n[j]
            if j==i:
                jacobianMatrix[i,j]=jacobianMatrix[i,j]+ (b[i]-d[i])
    
    
    growthRateT0 = f(0,n,b,d,eta,Cfun,x)
    
    res=np.linalg.lstsq(jacobianMatrix,-growthRateT0)[0]
    
    return(res+n)


def solver(n,b,d,eta,Cfun,x,tmut,epsLV=1e-5,epsExt=5e-2,dt=1):
    """
        Finds the equilibrium of the Lotka-Volterra ODE given the initial condition n.
        
        Integrates the Lotka-Volterra ODE over small time steps.
        When approaching equilibrium, calls newtonLV which gives more precise results.
    """

    #---- Creation of the ODE system (r)
    r=ode(f).set_integrator('vode', nsteps=5000)
    r.set_initial_value(n,0).set_f_params(b,d,eta,Cfun,x)

    #---- Determines the time scale of events.
    rpop=b-d
    dtScaled=dt/np.median(rpop)

        
    #---- Determines the characteristics to enter the attraction domain of the Newton method  (value from empirical tests)
    #     From the growth rate of each sub-population with initially low density: (0.1/(nbSubPop))*equilibrium density if alone
    nbSubPop=len(n)
    reference=np.zeros(nbSubPop)
    for i in range(nbSubPop):
        reference[i]=epsLV*steadyPop(b[i],d[i],eta[i],Cfun(0))/nbSubPop
    refDeriv=reference*min(abs(rpop))
    compDeriv=refDeriv
    
# # #     listT=[[0]]
# # #     popMutant=[[n]]

    #---- From initial densities, integrate the ODE => get nearer equilibrium.
    #         Do it until densities are within attraction domain of the Newton method
    #         => when all derivatives are low : refDeriv gives an order of magnitude of the derivatives in the system.
    nbTurns=0
    while r.successful() and ((max(abs(compDeriv)-abs(refDeriv))>=0) or (r.t<=1000*dtScaled) ) and (nbTurns < 5000):
        nbTurns += 1
        t=r.t        
        r.integrate(t+dtScaled)
        
        newDensities=r.y
        for i in range(nbSubPop):
            r.y[i]=max(newDensities[i],0)
            
# # #         listT.append(t)
# # #         popMutant.append(newDensities)
        
        compDeriv=f(t,newDensities,b,d,eta,Cfun,x)*rpop
 
    #---- Once the densities are within the attraction domain of the equilibrium: Newton method
    for i in range(100):
        newDensities=newtonLV(newDensities,b,d,eta,Cfun,x)
        
    #---- If the sub-population density is lower than a viability threshold, it gets extinct.
    for i in range(nbSubPop):
        if newDensities[i]<epsExt*reference[i]/epsLV:
            newDensities[i]=0
         
# # #     plt.figure()
# # #     plt.plot(listT,popMutant)
# # #     plt.title("t=%d" % tmut)
# # #     plt.show()

    return newDensities



def solveFromData(n,b,d,eta,Cfun,x,xmut,bmut,dmut,etamut,tmut,parent,alpha=1e-2,epsLV=1e-2,epsExt=1e-2,dt=1e-1):
    """
        Finds equilibrium density after the emergence of a rare mutant.
        
        Set initial densities: 
            low mutant density
            other sub-population at equilibrium without mutant
        Calls solver to get the equilibrium densities (given the initial densities)
        Suppress the extinct sub-populations
    """
    #---- Low initial density of the mutant (isolated equilibrium/alpha)
    nmut=alpha*steadyPop(bmut,dmut,etamut,Cfun(0))
    
    #---- Append the mutant to the sub-populations
    n=np.append(n,nmut)
    x=np.append(x,xmut)
    b=np.append(b,bmut)
    d=np.append(d,dmut)
    eta=np.append(eta,etamut)
    
    #---- Solve the ODE: densities of each sub-population at equilibrium
    resWithExtinct=solver(n,b,d,eta,Cfun,x,tmut,epsLV,epsExt,dt)
    
    #---- Suppress the extinct sub-populations
    mask= resWithExtinct!=0
    nres=resWithExtinct[mask,...]
    xres=x[mask,...]
    b=b[mask,...]
    d=d[mask,...]
    eta=eta[mask,...]
    parent=parent[mask,...]
    
    #---- Check if the mutant survived (otherwise, the PES is not modified).
    xmutSurvived= False
    for xval in xres:
        if  xmut == xval:
            xmutSurvived=True
            break
       
    return (nres,xres,b,d,eta,parent,xmutSurvived)




def solverF(n,b,d,eta,Cfun,x,xmut,bmut,dmut,etamut,tmut,subPopulations,alpha=1e-2,epsLV=1e-5,epsExt=5e-2,dt=1):
    """
        Finds the equilibrium of the Lotka-Volterra ODE given the initial condition n.
        
        Integrates the Lotka-Volterra ODE over small time steps.
        When approaching equilibrium, calls newtonLV which gives more precise results.
    """
    
    #---- Low initial density of the mutant (isolated equilibrium/alpha)
    nmut=alpha*steadyPop(bmut,dmut,etamut,Cfun(0))
    
    #---- Append the mutant to the sub-populations
    n=np.append(n,nmut)
    x=np.append(x,xmut)
    b=np.append(b,bmut)
    d=np.append(d,dmut)
    eta=np.append(eta,etamut)

    #---- Creation of the ODE system (r)
    r=ode(f).set_integrator('vode', nsteps=5000)
    r.set_initial_value(n,0).set_f_params(b,d,eta,Cfun,x)

    #---- Determines the time scale of events.
    rpop=b-d
    dtScaled=dt/np.median(rpop)

    #---- Each sub-population is given low density: (0.1/(nbSubPop))*equilibrium density if alone
    nbSubPop=len(n)
    reference=np.zeros(nbSubPop)
    for i in range(nbSubPop):
        reference[i]=epsLV*steadyPop(b[i],d[i],eta[i],Cfun(0))/nbSubPop
        
    #---- Determines the characteristics to enter the attraction domain of the Newton method  (value from empirical tests)
    refDeriv=reference*min(abs(rpop))
    compDeriv=refDeriv
    
# # #     listT=[[0]]
# # #     popMutant=[[n]]

    #---- From initial densities, integrate the ODE => get nearer equilibrium.
    #         Do it until densities are within attraction domain of the Newton method
    #         => when all derivatives are low : refDeriv gives an order of magnitude of the derivatives in the system.
    nbTurns=0
    while r.successful() and ((max(abs(compDeriv)-abs(refDeriv))>=0) or (r.t<=1000*dtScaled) ) and (nbTurns < 5000):
        nbTurns += 1
        t=r.t        
        r.integrate(t+dtScaled)
        
        newDensities=r.y
        for i in range(nbSubPop):
            r.y[i]=max(newDensities[i],0)
            
# # #         listT.append(t)
# # #         popMutant.append(newDensities)
        
        compDeriv=f(t,newDensities,b,d,eta,Cfun,x)*rpop
 
    #---- Once the densities are within the attraction domain of the equilibrium: Newton method
    for i in range(100):
        newDensities=newtonLV(newDensities,b,d,eta,Cfun,x)
        
    #---- If the sub-population density is lower than a viability threshold, it gets extinct.
    for i in reversed(range(nbSubPop)):
        if newDensities[i]<epsExt*reference[i]/epsLV:
            newDensities[i]=0
            
            #---- Suppress the extinct sub-populations
            newDensities = np.delete(newDensities, (i), axis=0)
            x=np.delete(x, (i))
            n=np.delete(n, (i))
            b=np.delete(b, (i))
            d=np.delete(d, (i))
            eta=np.delete(eta, (i))
            subPopulations[i].timeExtinction = tmut
            subPopulations=np.delete(subPopulations, (i))
            
# # #     plt.figure()
# # #     plt.plot(listT,popMutant)
# # #     plt.title("t=%d" % tmut)
# # #     plt.show()

      
    return (newDensities,x,b,d,eta,subPopulations)